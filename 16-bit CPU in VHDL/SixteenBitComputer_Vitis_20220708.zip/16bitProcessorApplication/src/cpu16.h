/************************************************************************/
/*																		*/
/*	display_demo.h	--	ZYBO display demonstration 						*/
/*																		*/
/************************************************************************/
/*	Author: Sam Bobrowicz												*/
/*	Copyright 2016, Digilent Inc.										*/
/************************************************************************/
/*  Module Description: 												*/
/*																		*/
/*		This file contains code for running a demonstration of the		*/
/*		HDMI output capabilities on the ZYBO. It is a good	            */
/*		example of how to properly use the display_ctrl drivers.	    */
/*																		*/
/************************************************************************/
/*  Revision History:													*/
/* 																		*/
/*		2/5/2016(SamB): Created											*/
/*																		*/
/************************************************************************/

#ifndef DISPLAY_DEMO_H_
#define DISPLAY_DEMO_H_

/* ------------------------------------------------------------ */
/*				Include File Definitions						*/
/* ------------------------------------------------------------ */

#include "xil_types.h"

/* ------------------------------------------------------------ */
/*					Miscellaneous Declarations					*/
/* ------------------------------------------------------------ */

#define DEMO_PATTERN_0 0
#define DEMO_PATTERN_1 1

//#define DEMO_MAX_FRAME (1920*1080*4)
//#define DEMO_STRIDE (1920 * 4)

#define MAX_FRAME (640 * 480 * 3)
#define STRIDE (640 * 3)



/* ------------------------------------------------------------ */
/*					Procedure Declarations						*/
/* ------------------------------------------------------------ */

void Initialize();
void DemoRun();
void DemoPrintMenu();
void DemoChangeRes();
void DemoCRMenu();
void DemoInvertFrame(u8 *srcFrame, u8 *destFrame, u32 width, u32 height, u32 stride);
void DemoPrintTest(u8 *frame, u32 width, u32 height, u32 stride, int pattern);

void PrintChar(char c, u16 start_x, u16 start_y, u8 frameNumber, u8 redVal, u8 greenVal, u8 blueVal);
void PrintString(char chars[], u16 numChars, u16 start_x, u16 start_y, u8 frameNumber, u8 colorNumber);
void DrawRectangle(u16 start_x, u16 start_y, u16 width, u16 height, u8 red, u8 green, u8 blue, u8 frameNumber);
void FillScreen(u8 red, u8 green, u8 blue, u8 frameNumber);
void DrawBarGraph8(u16 start_x, u16 start_y, char label[], u16 labelLength, u8 frameNumber);
void UpdateBarGraph8(u16 start_x, u16 start_y, u8 frameNumber, u8 value);
void DrawBarGraph16(u16 start_x, u16 start_y, char label[], u16 labelLength, u8 frameNumber);
void UpdateBarGraph16(u16 start_x, u16 start_y, u8 frameNumber, u8 colorNumber, u16 value);

void DrawClock(u16 start_x, u16 start_y, char label[], u16 labelLength, u8 frameNumber);
u8 GetClockFromGPIO();
void UpdateClock(u16 start_x, u16 start_y, u8 frameNumber, u8 colorNumber);

void CopyZeroFrameToOthers(u32 width, u32 height, u32 stride);

void UpdateDisplay();

void GetStepFromGPIO();
void GetProgramCounterFromGPIO();
void GetBusAddressFromGPIO();
void GetBusDataFromGPIO();
void GetRAMAddressFromGPIO();
void GetRAMDataFromGPIO();
void GetInstructionFromGPIO();
void GetControlRegFromGPIO();
void GetOutRegisterFromGPIO();
void GetRegisterAFromGPIO();
void GetRegisterXFromGPIO();
void GetRegisterYFromGPIO();
void GetALUFromGPIO();
void DrawControlText();
void DrawOpCodeText();
void SetColor(u8 colorNumber);
void GetDebugText1FromGPIO();
void UpdateDebugText1();
void UpdateRWText();
void GetRWFromGPIO();
void UpdateInitState();
void GetInitCompleteFromGPIO();
void GetRegisterIFromGPIO();


/* ------------------------------------------------------------ */
u32 cursorPos_Y;

/************************************************************************/

#endif /* DISPLAY_DEMO_H_ */
