//ctrl + shift + NUMPAD_divide = collapse all

/************************************************************************/
/*																		*/
/*	Portions adapted from Digilent Arty Z7-20 HDMI Out Demo  			*/
/*																		*/
/************************************************************************/

/* ------------------------------------------------------------ */
/*				Include File Definitions						*/
/* ------------------------------------------------------------ */

#include "cpu16.h"

#include "display_ctrl/display_ctrl.h"
#include <stdio.h>
#include "xuartps.h"
#include "math.h"
#include <ctype.h>
#include <stdlib.h>
#include "xil_types.h"
#include "xil_cache.h"
#include "timer_ps/timer_ps.h"
#include "xparameters.h"
#include "chars.c"
#include "xgpio.h"


#define GPIO_DEVICE_ID0		XPAR_AXI_GPIO_0_DEVICE_ID
#define GPIO_DEVICE_ID1 	XPAR_AXI_GPIO_1_DEVICE_ID
#define GPIO_DEVICE_ID2 	XPAR_AXI_GPIO_2_DEVICE_ID
#define GPIO_DEVICE_ID3 	XPAR_AXI_GPIO_3_DEVICE_ID
#define GPIO_DEVICE_ID4 	XPAR_AXI_GPIO_4_DEVICE_ID

/*
 * XPAR redefines
 */
#define DYNCLK_BASEADDR XPAR_AXI_DYNCLK_0_S_AXI_LITE_BASEADDR
#define VGA_VDMA_ID XPAR_AXIVDMA_0_DEVICE_ID
#define DISP_VTC_ID XPAR_VTC_0_DEVICE_ID
#define VID_VTC_IRPT_ID XPS_FPGA3_INT_ID
#define VID_GPIO_IRPT_ID XPS_FPGA4_INT_ID
#define SCU_TIMER_ID XPAR_SCUTIMER_DEVICE_ID
#define UART_BASEADDR XPAR_PS7_UART_0_BASEADDR

/* ------------------------------------------------------------ */
/*				Global Variables								*/
/* ------------------------------------------------------------ */

/*
 * Display Driver structs
 */
DisplayCtrl dispCtrl;
XAxiVdma vdma;


/*
 * Framebuffers for video data
 */
u8 frameBuf[DISPLAY_NUM_FRAMES][MAX_FRAME];
u8 *pFrames[DISPLAY_NUM_FRAMES]; //array of pointers to the frame buffers

/* ------------------------------------------------------------ */
/*				Procedure Definitions							*/
/* ------------------------------------------------------------ */
int nextFrame = 0;
u8 prevClockVal = 0;

XGpio Gpio0;
XGpio Gpio1;
XGpio Gpio2;
XGpio Gpio3;
XGpio Gpio4;
u32 gpio0_ch1_status=0;
u32 gpio0_ch2_status=0;
u32 gpio1_ch1_status=0;
u32 gpio1_ch2_status=0;
u32 gpio2_ch1_status=0;
u32 gpio2_ch2_status=0;
u32 gpio3_ch1_status=0;
u32 gpio3_ch2_status=0;
u32 gpio4_ch1_status=0;
u32 gpio4_ch2_status=0;

const u32 MASK_CLOCK			= 0b00000001;
const u32 MASK_STEP				= 0b00001110;

const u16 POS_CLOCK_X = 450;
const u16 POS_CLOCK_Y = 40;
const u16 POS_STEP_X = 180;
const u16 POS_STEP_Y = 40;
const u16 POS_PC_X = 235;
const u16 POS_PC_Y = 40;
const u16 POS_BUSADDR_X = 400;
const u16 POS_BUSADDR_Y = 40;
const u16 POS_BUSVAL_X = 500;
const u16 POS_BUSVAL_Y = 40;
const u16 POS_INST_X = 345;
const u16 POS_INST_Y = 40;
const u16 POS_RAMADDR_X = 500;
const u16 POS_RAMADDR_Y = 200;
const u16 POS_RAMVAL_X = 500;
const u16 POS_RAMVAL_Y = 255;
const u16 POS_REGA_X = 180;
const u16 POS_REGA_Y = 120;
const u16 POS_REGX_X = 280;
const u16 POS_REGX_Y = 120;
const u16 POS_REGY_X = 380;
const u16 POS_REGY_Y = 120;
const u16 POS_ALU_X = 500;
const u16 POS_ALU_Y = 120;
const u16 POS_REGI_X = 180;
const u16 POS_REGI_Y = 200;
const u16 POS_CONTROL2_X = 180;
const u16 POS_CONTROL2_Y = 280;
const u16 POS_CONTROL_X = 269;
const u16 POS_CONTROL_Y = 280;
const u16 POS_FLAGS_X = 380;
const u16 POS_FLAGS_Y = 280;
const u16 POS_OUT_X = 500;
const u16 POS_OUT_Y = 280;
const u16 POS_SUPPORTED_OPCODES_X = 5;
const u16 POS_SUPPORTED_OPCODES_Y = 460;
const u16 POS_CONTROL_TEXT_X = 5;
const u16 POS_CONTROL_TEXT_Y = 445;
const u16 POS_CONTROL_DEBUGTEXT1_X = 20;
const u16 POS_CONTROL_DEBUGTEXT1_Y = 400;


const u8 COLOR_RED = 0;
const u8 COLOR_GREEN = 1;
const u8 COLOR_BLUE = 2;
const u8 COLOR_WHITE = 3;
const u8 COLOR_PURPLE = 4;
const u8 COLOR_YELLOW = 5;
const u8 COLOR_TEAL = 6;
const u8 COLOR_BLACK = 7;
const u8 COLOR_DARK_GREY = 255;	//background grey

u8 Val_Clock = 0;
u8 Val_Step = 0;
u16 Val_ProgramCounter = 0;
u16 Val_BusAddress = 0;
u16 Val_BusData = 0;
u16 Val_Instruction = 0;
u16 Val_RAMAddress = 0;
u16 Val_RAMData = 0;
u16 Val_RegisterA = 0;
u16 Val_RegisterX = 0;
u16 Val_RegisterY = 0;
u16 Val_RegisterI = 0;
u16 Val_ALU = 0;
u32 Val_ControlReg = 0;
u16 Val_Flags = 0;
u16 Val_Out = 0;
u16 Val_DebugText1 = 0;
u16 Val_ExtAddr = 0;
u16 Val_ExtData = 0;
//u8 Val_RW = 0;
u8 Val_InitComplete = 0;

u8 setRed, setGreen, setBlue;

int main(void)
{
	Initialize();

	int gpio0_status = XGpio_Initialize(&Gpio0, GPIO_DEVICE_ID0);
	int gpio1_status = XGpio_Initialize(&Gpio1, GPIO_DEVICE_ID1);
	int gpio2_status = XGpio_Initialize(&Gpio2, GPIO_DEVICE_ID2);
	int gpio3_status = XGpio_Initialize(&Gpio3, GPIO_DEVICE_ID3);
	int gpio4_status = XGpio_Initialize(&Gpio4, GPIO_DEVICE_ID4);

    Gpio0.IsDual=1;		//automatically seen as dual correctly
    Gpio1.IsDual=1;		//have to manually set to see it as a dual (bug?)
    Gpio2.IsDual=1;
    Gpio3.IsDual=1;
    Gpio4.IsDual=1;

    //initial screen drawing (processor off)
	nextFrame = dispCtrl.curFrame + 1;
	if (nextFrame >= DISPLAY_NUM_FRAMES)
	{
		nextFrame = 0;
	}
	FillScreen(0,0,150,dispCtrl.curFrame);
	PrintString("Initializing...",15,5,5, dispCtrl.curFrame,COLOR_WHITE);
	Xil_DCacheFlushRange((unsigned int) dispCtrl.curFrame, MAX_FRAME);
	DisplayChangeFrame(&dispCtrl, nextFrame);	//move to frame 1, so that we can update frame 0


	//populate frame 0 -- will copy to other frames
	FillScreen(31,31,31, 0);
	PrintString("16-Bit Processor",16,5,5, 0, COLOR_WHITE);

	PrintString("INIT:",5,5,30, 0, COLOR_WHITE);
	PrintString("0000:0x00AD  LDA",16,5,40, 0, COLOR_TEAL);
	PrintString("0001:0x00FC  value to load",26,5,50, 0, COLOR_TEAL);
	PrintString("0002:0x0042  JMPA",17,5,60, 0, COLOR_TEAL);

	PrintString("PROGRAM*:",9,5,80, 0, COLOR_WHITE);

	PrintString("0080:0x00A9  LDAI",17,5,90, 0, COLOR_GREEN);
	PrintString("0081:0xC003      ",17,5,100, 0, COLOR_GREEN);
	PrintString("0082:0x00A2  LDXI",17,5,110, 0, COLOR_GREEN);
	PrintString("0083:0x300C      ",17,5,120, 0, COLOR_GREEN);
	PrintString("0084:0x00A0  LDYI",17,5,130, 0, COLOR_GREEN);
	PrintString("0085:0x0C30      ",17,5,140, 0, COLOR_GREEN);
	PrintString("0086:0x00FB  LDII",17,5,150, 0, COLOR_GREEN);
	PrintString("0087:0x03C0      ",17,5,160, 0, COLOR_GREEN);
	PrintString("0088:0x0069  ADCI",17,5,170, 0, COLOR_GREEN);
	PrintString("0089:0x0101      ",17,5,180, 0, COLOR_GREEN);
	PrintString("008A:0x00E9  SBCI",17,5,190, 0, COLOR_GREEN);
	PrintString("008B:0x0001      ",17,5,200, 0, COLOR_GREEN);

	PrintString("008C:0x008D  STAA",17,5,210, 0, COLOR_GREEN);
	PrintString("008D:0x0000      ",17,5,220, 0, COLOR_GREEN);
	PrintString("008E:0x00A9  LDAI",17,5,230, 0, COLOR_GREEN);
	PrintString("008F:0xFFFF      ",17,5,240, 0, COLOR_GREEN);
	PrintString("0090:0x00AD  LDAA",17,5,250, 0, COLOR_GREEN);
	PrintString("0091:0x0000      ",17,5,260, 0, COLOR_GREEN);

	PrintString("008C:0x004C  JMP ",17,5,270, 0, COLOR_GREEN);
	PrintString("008C:0x0088      ",17,5,280, 0, COLOR_GREEN);
	PrintString("00FC:0x0080",11,5,290, 0, COLOR_GREEN);

	PrintString("*Jump to reset vector, load test values into registers, add, subtract,",70,5,350, 0, COLOR_WHITE);
	PrintString(" store A to $0x0A, load a test value, retrieve A, jump back to add.",67,5,360, 0, COLOR_WHITE);
	//PrintString("load values into registers,",27,5,330, 0, COLOR_WHITE);
	//PrintString("add, subtract, store,",21,5,340, 0, COLOR_WHITE);
	//PrintString("load, retrieve, stop",20,5,350, 0, COLOR_WHITE);
	//PrintString("--STP in this case.",19,5,340, 0, COLOR_WHITE);

	PrintString(" Supported OpCodes: LDAA,LDAI,LDXI,LDYI,LDII,ADCI,STP,NOP,JMPA,SBCI",67, POS_SUPPORTED_OPCODES_X, POS_SUPPORTED_OPCODES_Y, 0, COLOR_TEAL);

	DrawClock(POS_CLOCK_X,POS_CLOCK_Y,"CLOCK", 5, 0);

	DrawBarGraph8(POS_STEP_X,POS_STEP_Y, "  STEP", 6, 0);
	DrawBarGraph16(POS_PC_X,POS_PC_Y, "PROG COUNTER ", 13, 0);
	//DrawBarGraph16(POS_BUSADDR_X,POS_BUSADDR_Y, " BUS ADDRESS ", 13, 0);
	DrawBarGraph16(POS_BUSVAL_X,POS_BUSVAL_Y, "INTERNAL BUS ", 13, 0);
	DrawBarGraph8(POS_INST_X, POS_INST_Y, "  INST", 6, 0);
	DrawBarGraph16(POS_RAMADDR_X,POS_RAMADDR_Y, "  ADDRESS", 9, 0);
	DrawBarGraph16(POS_RAMVAL_X,POS_RAMVAL_Y, "  DATA  ", 8, 0);
	DrawBarGraph16(POS_REGA_X,POS_REGA_Y, "  REGISTER A ", 13, 0);
	DrawBarGraph16(POS_REGX_X,POS_REGX_Y, "  REGISTER X ", 13, 0);
	DrawBarGraph16(POS_REGY_X,POS_REGY_Y, "  REGISTER Y ", 13, 0);
	DrawBarGraph16(POS_REGI_X, POS_REGI_Y, "  REGISTER I ", 13, 0);
	DrawBarGraph16(POS_ALU_X,POS_ALU_Y, "     ALU     ", 13, 0);
	DrawBarGraph16(POS_FLAGS_X,POS_FLAGS_Y, "    FLAGS    ", 13, 0);

	DrawBarGraph16(POS_CONTROL2_X,POS_CONTROL2_Y, "CONTROL UPPER", 13, 0);
	DrawBarGraph16(POS_CONTROL_X,POS_CONTROL_Y, "CONTROL LOWER", 13, 0);

	//DrawBarGraph16(POS_OUT_X,POS_OUT_Y, "     OUT     ", 13, 0);
	DrawRectangle(POS_RAMADDR_X - 10, POS_RAMADDR_Y - 20, 110, 1, 100, 100, 100, 0);
	DrawRectangle(POS_RAMADDR_X - 10, POS_RAMADDR_Y +100, 110, 1, 100, 100, 100, 0);
	DrawRectangle(POS_RAMADDR_X - 10, POS_RAMADDR_Y - 20, 1, 120, 100, 100, 100, 0);
	DrawRectangle(POS_RAMADDR_X + 100, POS_RAMADDR_Y - 20, 1, 120, 100, 100, 100, 0);
	PrintString("*EXTERNAL*", 10, POS_RAMADDR_X, POS_RAMADDR_Y-28, 0, COLOR_PURPLE);

	//DrawBarGraph16(POS_EXTERNAL_ADDRESS_X, POS_EXTERNAL_ADDRESS_Y, " EXT ADDRESS ", 13, 0);
	//DrawBarGraph16(POS_EXTERNAL_DATA_X, POS_EXTERNAL_DATA_Y, " EXT DATA    ", 13, 0);

	//copy frame to others
	Xil_DCacheFlushRange((unsigned int) 0, MAX_FRAME);	//flush writes on frame 0
	CopyZeroFrameToOthers(dispCtrl.vMode.width, dispCtrl.vMode.height, dispCtrl.stride);

	DisplayChangeFrame(&dispCtrl, nextFrame);	//move to frame 2

    if (gpio0_status == XST_SUCCESS && gpio1_status == XST_SUCCESS && gpio2_status == XST_SUCCESS && gpio3_status == XST_SUCCESS && gpio4_status == XST_SUCCESS)
    {
        XGpio_SetDataDirection(&Gpio0, 1, 0xffffffff);		//gpio, channel, direction
        XGpio_SetDataDirection(&Gpio0, 2, 0xffffffff);		//gpio, channel, direction
        XGpio_SetDataDirection(&Gpio1, 1, 0xffffffff);		//gpio, channel, direction
        XGpio_SetDataDirection(&Gpio1, 2, 0xffffffff);		//gpio, channel, direction
        XGpio_SetDataDirection(&Gpio2, 1, 0xffffffff);		//gpio, channel, direction
        XGpio_SetDataDirection(&Gpio2, 2, 0xffffffff);		//gpio, channel, direction
        XGpio_SetDataDirection(&Gpio3, 1, 0xffffffff);		//gpio, channel, direction
        XGpio_SetDataDirection(&Gpio3, 2, 0xffffffff);		//gpio, channel, direction
        XGpio_SetDataDirection(&Gpio4, 1, 0xffffffff);		//gpio, channel, direction
        XGpio_SetDataDirection(&Gpio4, 2, 0xffffffff);		//gpio, channel, direction

		while(1)		//loop forever
		{

			gpio0_ch1_status = XGpio_DiscreteRead(&Gpio0, 1);		//gpio, channel
			gpio0_ch2_status = XGpio_DiscreteRead(&Gpio0, 2);		//gpio, channel
			gpio1_ch1_status = XGpio_DiscreteRead(&Gpio1, 1);		//gpio, channel
			gpio1_ch2_status = XGpio_DiscreteRead(&Gpio1, 2);		//gpio, channel
			gpio2_ch1_status = XGpio_DiscreteRead(&Gpio2, 1);		//gpio, channel
			gpio2_ch2_status = XGpio_DiscreteRead(&Gpio2, 2);		//gpio, channel
			gpio3_ch1_status = XGpio_DiscreteRead(&Gpio3, 1);		//gpio, channel
			gpio3_ch2_status = XGpio_DiscreteRead(&Gpio3, 2);		//gpio, channel
			gpio4_ch1_status = XGpio_DiscreteRead(&Gpio4, 1);		//gpio, channel
			gpio4_ch2_status = XGpio_DiscreteRead(&Gpio4, 2);		//gpio, channel


			//TO DO get all values right away, then update UI
			u8 clockVal = GetClockFromGPIO();
			Val_Clock = clockVal;


			if(clockVal ==1 && prevClockVal == 0)	//only update on rise for now
			{
				Val_Clock = 1;
				GetProgramCounterFromGPIO();
				//GetBusAddressFromGPIO();
				GetBusDataFromGPIO();
				GetRAMAddressFromGPIO();
				GetRAMDataFromGPIO();
				//GetInstructionFromGPIO();
				GetOutRegisterFromGPIO();
				GetRegisterAFromGPIO();
				GetRegisterXFromGPIO();
				GetRegisterYFromGPIO();
				GetRegisterIFromGPIO();
				GetALUFromGPIO();
				GetDebugText1FromGPIO();
				GetInitCompleteFromGPIO();
				UpdateDisplay();
				prevClockVal = 1;
			}
			else if(clockVal ==0 && prevClockVal == 1)	//fall
			{
				Val_Clock = 0;

				//update Step and Control
				GetStepFromGPIO();
				GetInstructionFromGPIO();
				GetControlRegFromGPIO();
				GetDebugText1FromGPIO();
				UpdateDisplay();
				prevClockVal = 0;
			}
			else
			{
				//Only update control reg outside of clock fall if HALT		//GetControlRegFromGPIO();
				if(gpio3_ch2_status & 0b1000000000000000)	//HALT
				{
					Val_ControlReg = gpio3_ch2_status;
					UpdateDisplay();
				}
			}
		}

    }
	//DemoRun();
	return 0;
}

void UpdateDisplay()
{
	nextFrame = dispCtrl.curFrame + 1;
	if (nextFrame >= DISPLAY_NUM_FRAMES)
	{
		nextFrame = 0;
	}

	if(Val_Clock)
	{
		UpdateClock(POS_CLOCK_X,POS_CLOCK_Y,nextFrame, 4);
	}
	else
	{
		UpdateClock(POS_CLOCK_X,POS_CLOCK_Y,nextFrame, 255);
	}

	UpdateBarGraph8(POS_STEP_X,POS_STEP_Y,nextFrame, Val_Step);

	UpdateBarGraph16(POS_PC_X,POS_PC_Y, nextFrame, 1, Val_ProgramCounter);
	//UpdateBarGraph16(POS_BUSADDR_X,POS_BUSADDR_Y, nextFrame, 0, Val_BusAddress);
	UpdateBarGraph16(POS_BUSVAL_X,POS_BUSVAL_Y, nextFrame, 0, Val_BusData);

	UpdateBarGraph8(POS_INST_X, POS_INST_Y, nextFrame, Val_Instruction);
	DrawOpCodeText();
	UpdateBarGraph16(POS_RAMADDR_X,POS_RAMADDR_Y, nextFrame,0, Val_RAMAddress);
	UpdateBarGraph16(POS_RAMVAL_X,POS_RAMVAL_Y, nextFrame,0, Val_RAMData);

	UpdateBarGraph16(POS_REGA_X,POS_REGA_Y, nextFrame,2, Val_RegisterA);
	UpdateBarGraph16(POS_REGX_X,POS_REGX_Y, nextFrame,2, Val_RegisterX);
	UpdateBarGraph16(POS_REGY_X,POS_REGY_Y, nextFrame,2, Val_RegisterY);
	UpdateBarGraph16(POS_REGI_X,POS_REGI_Y, nextFrame,2, Val_RegisterI);
	UpdateBarGraph16(POS_ALU_X,POS_ALU_Y, nextFrame,7, Val_ALU);

	UpdateBarGraph16(POS_FLAGS_X,POS_FLAGS_Y, nextFrame,3, Val_Flags);
	UpdateBarGraph16(POS_CONTROL_X,POS_CONTROL_Y, nextFrame, 3, Val_ControlReg&0x0000FFFF);
	UpdateBarGraph16(POS_CONTROL2_X,POS_CONTROL2_Y, nextFrame, 3, (Val_ControlReg&0xFFFF0000)>>16);
	DrawControlText();
	//UpdateBarGraph16(POS_OUT_X,POS_OUT_Y, nextFrame,0, Val_Out);
	//UpdateBarGraph16(POS_EXTERNAL_ADDRESS_X, POS_EXTERNAL_ADDRESS_Y, nextFrame,0, Val_ExtAddr);
	//UpdateBarGraph16(POS_EXTERNAL_DATA_X, POS_EXTERNAL_DATA_Y, nextFrame,0, Val_ExtData);
	UpdateRWText();
	UpdateInitState();

	UpdateDebugText1();
	Xil_DCacheFlushRange((unsigned int) nextFrame, MAX_FRAME);
	DisplayChangeFrame(&dispCtrl, nextFrame);

}



u8 GetClockFromGPIO()
{
		if(gpio0_ch1_status & MASK_CLOCK)
		{
			return 1;
		}
		else	//off
		{
			return 0;
		}
}
//void GetRWFromGPIO()
//{
//	Val_RW = (gpio0_ch1_status & 0b00110000)>>4;
//}
void GetStepFromGPIO()
{
	Val_Step = (gpio0_ch1_status & MASK_STEP)>>1;
}
void GetProgramCounterFromGPIO()
{
	Val_ProgramCounter = (gpio3_ch1_status & 0xFFFF0000) >> 16;
}
void GetBusAddressFromGPIO()
{
	Val_BusAddress = (gpio0_ch2_status & 0x0000FFFF);
}
void GetBusDataFromGPIO()
{
	Val_BusData = (gpio0_ch2_status & 0xFFFF0000) >> 16;
}
void GetControlRegFromGPIO()
{
	Val_ControlReg = (gpio3_ch2_status);	//32 bits avail. for control
}
void GetRAMAddressFromGPIO()
{
	Val_RAMAddress = (gpio1_ch1_status & 0x0000FFFF);
}
void GetRAMDataFromGPIO()
{
	Val_RAMData = (gpio1_ch1_status & 0xFFFF0000) >> 16;
}
void GetInstructionFromGPIO()
{
	Val_Instruction = (gpio0_ch1_status & 0x00FFFF00) >> 8;
}
void GetOutRegisterFromGPIO()
{
	Val_Out = (gpio3_ch1_status & 0x0000FFFF);
}
void GetRegisterAFromGPIO()
{
	Val_RegisterA = (gpio1_ch2_status & 0x0000FFFF);
}
void GetRegisterXFromGPIO()
{
	Val_RegisterX = (gpio1_ch2_status & 0xFFFF0000)>>16;
}
void GetRegisterYFromGPIO()
{
	Val_RegisterY = (gpio2_ch1_status & 0x0000FFFF);
}
void GetRegisterIFromGPIO()
{
	Val_RegisterI = (gpio4_ch1_status & 0x0000FFFF);
}
void GetALUFromGPIO()
{
	Val_ALU = (gpio2_ch1_status & 0xFFFF0000)>>16;
}
void GetDebugText1FromGPIO()
{
	Val_DebugText1 = (gpio2_ch2_status & 0x0000FFFF);
}
void GetInitCompleteFromGPIO()
{
	Val_InitComplete = (gpio0_ch1_status & 0b00010000)>>4;
}
void DrawControlText()
{
	u8 newColor;
	char ControlName[5];
	u8 numberControls = 21;

	//erase space for text out
	DrawRectangle(POS_CONTROL_TEXT_X, POS_CONTROL_TEXT_Y, 630, 12, 60, 60, 60, nextFrame);
	for(int i=0; i<numberControls;i++)
	{
		if((1<<(numberControls-1-i))&Val_ControlReg)
		{
			//STP / MEMADDRIN // NEXTADDOUT / RAMIN / RAMOUT / INSTOUT / INSTIN / AIN / AOUT / SUMOUT / SUBTRACT / BIN / OUTREGIN / COUNTEN / COUNTOUT / JUMP / FI
			newColor = COLOR_GREEN;
		}
		else
		{
			newColor = COLOR_BLACK;
		}

		switch(i)
		{
		case 0:
			strcpy(ControlName, "IOUT");
			break;
		case 1:
			strcpy(ControlName, "IIN ");
			break;
		case 2:
			strcpy(ControlName, "YOUT");
			break;
		case 3:
			strcpy(ControlName, "YIN ");
			break;
		case 4:
			strcpy(ControlName, "XOUT");
			break;
		case 5:
			strcpy(ControlName, "HALT");
			break;
		case 6:
			strcpy(ControlName, "MAIN");
			break;
		case 7:
			strcpy(ControlName, "MEMI");
			break;
		case 8:
			strcpy(ControlName, "MEMO");
			break;
		case 9:
			strcpy(ControlName, "INSO");
			break;
		case 10:
			strcpy(ControlName, "INSI");
			break;
		case 11:
			strcpy(ControlName, "AIN ");
			break;
		case 12:
			strcpy(ControlName, "AOUT");
			break;
		case 13:
			strcpy(ControlName, "SUMO");
			break;
		case 14:
			strcpy(ControlName, "SUB ");
			break;
		case 15:
			strcpy(ControlName, "XIN ");
			break;
		case 16:
			strcpy(ControlName, "OUT ");
			break;
		case 17:
			strcpy(ControlName, "CNTE");
			break;
		case 18:
			strcpy(ControlName, "CNTO");
			break;
		case 19:
			strcpy(ControlName, "JUMP");
			break;
		case 20:
			strcpy(ControlName, " FI ");
			break;
		}

		PrintString(ControlName, 4, POS_CONTROL_TEXT_X+2 + 30*i, POS_CONTROL_TEXT_Y+2, nextFrame, newColor);
	}
}
void UpdateDebugText1()
{
	DrawRectangle(POS_CONTROL_DEBUGTEXT1_X, POS_CONTROL_DEBUGTEXT1_Y, 180, 8, 31,31,31, nextFrame);
	char outString[29];
	sprintf(outString, "Microcode line number: %5i", Val_DebugText1);
	PrintString(outString, 28, POS_CONTROL_DEBUGTEXT1_X+2, POS_CONTROL_DEBUGTEXT1_Y, nextFrame, COLOR_WHITE);
}

void UpdateRWText()
{
	char outChar[2];
	outChar[0] = 'R';
	if(Val_ControlReg & 0b0001000000000000)
	{

		PrintChar(outChar[0], POS_RAMVAL_X + 70, POS_RAMVAL_Y - 10, nextFrame, 255, 255, 0);
	}
	else
	{
		PrintChar(outChar[0], POS_RAMVAL_X + 70, POS_RAMVAL_Y - 10, nextFrame, 50, 50, 50);
	}
	outChar[0] = 'W';
	if(Val_ControlReg & 0b0010000000000000)
	{
		PrintChar(outChar[0], POS_RAMVAL_X + 76, POS_RAMVAL_Y - 10, nextFrame, 255, 255, 0);
	}
	else
	{
		PrintChar(outChar[0], POS_RAMVAL_X + 76, POS_RAMVAL_Y - 10, nextFrame, 50, 50, 50);
	}
}
void UpdateInitState()
{
	DrawRectangle(20, POS_CONTROL_DEBUGTEXT1_Y + 10, 300, 8, 31,31,31, nextFrame);
	char outChars[50];
	if(Val_InitComplete)
	{
		strcpy(outChars, "Initialized using reset vector 0x0080");
		PrintString(outChars,37,20, POS_CONTROL_DEBUGTEXT1_Y + 10, nextFrame, COLOR_GREEN);
	}
	else
	{
		strcpy(outChars, "Initializing... Getting vector from 0x00FC");
		PrintString(outChars,42,20, POS_CONTROL_DEBUGTEXT1_Y + 10, nextFrame, COLOR_RED);
	}
}

void DrawOpCodeText()
{
	//erase space
	DrawRectangle(POS_INST_X+55, POS_INST_Y+7, 25, 8, 31,31,31, nextFrame);
	char OpCode[5];
	switch(Val_Instruction)
	{
	case 0x42:
		sprintf(OpCode, "JMPA");
		break;
	case 0x4C:
		sprintf(OpCode, "JMP ");
		break;
	case 0x69:
		sprintf(OpCode, "ADCI");
		break;
	case 0xA0:
		sprintf(OpCode, "LDYI");
		break;
	case 0x8D:
		sprintf(OpCode, "STAA");
		break;
	case 0xA2:
		sprintf(OpCode, "LDXI");
		break;
	case 0xA9:
		sprintf(OpCode, "LDAI");
		break;
	case 0xAD:
		sprintf(OpCode, "LDAA");
		break;
	case 0xDB:
		sprintf(OpCode, "STP ");
		break;
	case 0xE9:
		sprintf(OpCode, "SBCI");
		break;
	case 0xEA:
		sprintf(OpCode, "NOP ");
		break;
	case 0xFB:
		sprintf(OpCode, "LDII");
		break;
	default:
		sprintf(OpCode, " ?  ");
		break;
	}
	PrintString(OpCode, 4, POS_INST_X+55, POS_INST_Y+7, nextFrame, COLOR_GREEN);
}
void DrawBarGraph8(u16 start_x, u16 start_y, char label[], u16 labelLength, u8 frameNumber)
{
	DrawRectangle(start_x, start_y, 48, 20, 0, 0, 0, frameNumber);

	for(int i=0; i<8;i++)
	{
		DrawRectangle(start_x+(i+1)*5, start_y+4, 4, 12, 16, 32, 32, frameNumber);
	}

	//3D effect
	DrawRectangle(start_x+1, start_y+20, 48, 1, 128, 128, 128, frameNumber);
	DrawRectangle(start_x+2, start_y+21, 48, 1, 128, 128, 128, frameNumber);
	DrawRectangle(start_x+3, start_y+22, 48, 1, 128, 128, 128, frameNumber);

	DrawRectangle(start_x+48, start_y+1, 1, 20, 64, 64, 64, frameNumber);
	DrawRectangle(start_x+49, start_y+2, 1, 20, 64, 64, 64, frameNumber);
	DrawRectangle(start_x+50, start_y+3, 1, 20, 64, 64, 64, frameNumber);

	PrintString(label, labelLength, start_x+2, start_y-10, frameNumber, COLOR_WHITE);
}
void UpdateBarGraph8(u16 start_x, u16 start_y, u8 frameNumber, u8 value)
{
	for(int i=0; i<8;i++)
	{
		if((1<<(7-i))&value)
		{
			DrawRectangle(start_x+(i+1)*5, start_y+4, 4, 12, 255, 0, 0, frameNumber);
		}
		else	//off
		{
			DrawRectangle(start_x+(i+1)*5, start_y+4, 4, 12, 16, 32, 32, frameNumber);
		}
	}

	//erase space
	DrawRectangle(start_x+2, start_y+30, 50, 8, 31,31,31, frameNumber);
	char hexString[5];
	sprintf(hexString, "0x%02X", value);
	PrintString(hexString, 4, start_x+5, start_y+30, frameNumber, 5);
	char intString[4];
	sprintf(intString, "%3i", value);
	PrintString(intString, 3,start_x+33, start_y+30, frameNumber, 6);
}

void DrawBarGraph16(u16 start_x, u16 start_y, char label[], u16 labelLength, u8 frameNumber)
{
	DrawRectangle(start_x, start_y, 88, 20, 0, 0, 0, frameNumber);

	for(int i=0; i<16;i++)
	{
		DrawRectangle(start_x+(i+1)*5, start_y+4, 4, 12, 16, 32, 32, frameNumber);
	}

	//3D effect
	DrawRectangle(start_x+1, start_y+20, 88, 1, 128, 128, 128, frameNumber);
	DrawRectangle(start_x+2, start_y+21, 88, 1, 128, 128, 128, frameNumber);
	DrawRectangle(start_x+3, start_y+22, 88, 1, 128, 128, 128, frameNumber);

	DrawRectangle(start_x+88, start_y+1, 1, 20, 64, 64, 64, frameNumber);
	DrawRectangle(start_x+89, start_y+2, 1, 20, 64, 64, 64, frameNumber);
	DrawRectangle(start_x+90, start_y+3, 1, 20, 64, 64, 64, frameNumber);

	PrintString(label, labelLength, start_x+2, start_y-10, frameNumber, COLOR_WHITE);
}
void UpdateBarGraph16(u16 start_x, u16 start_y, u8 frameNumber, u8 colorNumber, u16 value)
{
	u8 redVal, greenVal, blueVal;
	if(colorNumber==0)
	{
		redVal = 255;
		greenVal = 0;
		blueVal = 0;
	}
	else if(colorNumber==1)
	{
		redVal = 0;
		greenVal = 255;
		blueVal = 0;
	}
	else if(colorNumber==2)
	{
		redVal = 0;
		greenVal = 0;
		blueVal = 255;
	}
	else if(colorNumber==3)
	{
		redVal = 255;
		greenVal = 255;
		blueVal = 255;
	}
	else if(colorNumber==4)
	{
		redVal = 64;
		greenVal = 255;
		blueVal = 64;
	}
	else if(colorNumber==5)
	{
		redVal = 128;
		greenVal = 128;
		blueVal = 255;
	}
	else if(colorNumber==6)
	{
		redVal = 128;
		greenVal = 255;
		blueVal = 255;
	}
	else if(colorNumber==7)
	{
		redVal = 128;
		greenVal = 128;
		blueVal = 200;
	}

	for(int i=0; i<16;i++)
	{
		if((1<<(15-i))&value)
		{
			DrawRectangle(start_x+(i+1)*5, start_y+4, 4, 12, redVal, greenVal, blueVal, frameNumber);
		}
		else
		{
			DrawRectangle(start_x+(i+1)*5, start_y+4, 4, 12, 16, 32, 32, frameNumber);
		}
	}

	//erase space
	DrawRectangle(start_x+2, start_y+30, 84, 8, 31,31,31, frameNumber);

	char hexString[7];
	sprintf(hexString, "0x%04X", value);
	PrintString(hexString, 6, start_x+5, start_y+30, frameNumber, 5);
	char intString[6];
	sprintf(intString, "%5i", value);
	PrintString(intString, 5,start_x+51, start_y+30, frameNumber, 6);
}


void DrawClock(u16 start_x, u16 start_y, char label[], u16 labelLength, u8 frameNumber)
{
	DrawRectangle(start_x, start_y, 23, 20, 0, 0, 0, frameNumber);
	DrawRectangle(start_x+5, start_y+4, 12, 12, 16, 32, 32, frameNumber);	//off

	//3D effect
	DrawRectangle(start_x+1, start_y+20, 23, 1, 128, 128, 128, frameNumber);
	DrawRectangle(start_x+2, start_y+21, 23, 1, 128, 128, 128, frameNumber);
	DrawRectangle(start_x+3, start_y+22, 23, 1, 128, 128, 128, frameNumber);

	DrawRectangle(start_x+23, start_y+1, 1, 20, 64, 64, 64, frameNumber);
	DrawRectangle(start_x+24, start_y+2, 1, 20, 64, 64, 64, frameNumber);
	DrawRectangle(start_x+25, start_y+3, 1, 20, 64, 64, 64, frameNumber);

	PrintString(label, labelLength, start_x-1, start_y-10, frameNumber, COLOR_WHITE);
}
void UpdateClock(u16 start_x, u16 start_y, u8 frameNumber, u8 colorNumber)
{
	u8 redVal, greenVal, blueVal;
	if(colorNumber==0)
	{
		redVal = 255;
		greenVal = 0;
		blueVal = 0;
	}
	else if(colorNumber==1)
	{
		redVal = 0;
		greenVal = 255;
		blueVal = 0;
	}
	else if(colorNumber==2)
	{
		redVal = 0;
		greenVal = 0;
		blueVal = 255;
	}
	else if(colorNumber==3)
	{
		redVal = 255;
		greenVal = 255;
		blueVal = 255;
	}
	else if(colorNumber==4)
	{
		redVal = 255;
		greenVal = 128;
		blueVal = 255;
	}
	else if(colorNumber==255)
	{
		redVal = 16;
		greenVal = 32;
		blueVal = 32;
	}

	DrawRectangle(start_x+5, start_y+4, 12, 12, redVal, greenVal, blueVal, frameNumber);
	//Xil_DCacheFlushRange((unsigned int) frameNumber, MAX_FRAME);
}

void FillScreen(u8 red, u8 green, u8 blue, u8 frameNumber)
{
	u8 *frame = dispCtrl.framePtr[frameNumber];

	for(u32 col = 0; col<640*3; col+=3)
	{
		for(u32 row = 0; row<480; row++)
		{
			frame[(row*dispCtrl.stride) + col] = red;
			frame[(row*dispCtrl.stride) + col + 1] = green;
			frame[(row*dispCtrl.stride) + col + 2] = blue;
		}
	}
	/*
	 * Flush the framebuffer memory range to ensure changes are written to the
	 * actual memory, and therefore accessible by the VDMA.
	 */
	Xil_DCacheFlushRange((unsigned int) frame, MAX_FRAME);
}

void DrawRectangle(u16 start_x, u16 start_y, u16 width, u16 height, u8 red, u8 green, u8 blue, u8 frameNumber)
{
	u8 *frame = dispCtrl.framePtr[frameNumber];

	for(u32 col = start_x*3; col<(start_x+width)*3; col+=3)
	{
		for(u32 row = start_y; row<(start_y+height); row++)
		{
			frame[(row*dispCtrl.stride) + col] = red;
			frame[(row*dispCtrl.stride) + col + 1] = green;
			frame[(row*dispCtrl.stride) + col + 2] = blue;
		}
	}
	//Xil_DCacheFlushRange((unsigned int) frame, MAX_FRAME);
}


void PrintChar(char c, u16 start_x, u16 start_y, u8 frameNumber, u8 redVal, u8 greenVal, u8 blueVal)
{
	u8 *frame = dispCtrl.framePtr[frameNumber];

	for(u32 row = 0; row<7; row++)
	{
		for(u32 col = 0; col<5; col++)
		{
			if(charLookup[(u8)c][row][col]==1)
			{
				frame[(row+start_y)*dispCtrl.stride + (col+start_x)*3]= redVal;
				frame[(row+start_y)*dispCtrl.stride + (col+start_x)*3 +1]= greenVal;
				frame[(row+start_y)*dispCtrl.stride + (col+start_x)*3 +2]= blueVal;
			}
		}
	}

	Xil_DCacheFlushRange((unsigned int) frame, MAX_FRAME);
}

void SetColor(u8 colorNumber)
{
	//up to 255 "favorite" colors
	switch(colorNumber)
	{
	case 0:					//red
		setRed = 255;
		setGreen = 0;
		setBlue = 0;
		break;
	case 1:					//green
		setRed = 0;
		setGreen = 255;
		setBlue = 0;
		break;
	case 2:					//blue
		setRed = 0;
		setGreen = 0;
		setBlue = 255;
		break;
	case 3:					//white
		setRed = 255;
		setGreen = 255;
		setBlue = 255;
		break;
	case 4:
		setRed = 255;		//less green
		setGreen = 128;
		setBlue = 255;
		break;
	case 5:
		setRed = 255;
		setGreen = 255;
		setBlue = 128;		//less blue
		break;
	case 6:
		setRed = 128;		//less red
		setGreen = 255;
		setBlue = 255;
		break;
	case 7:					//black
		setRed = 0;
		setGreen = 0;
		setBlue = 0;
		break;
	case 255:				//dark grey
		setRed = 16;
		setGreen = 32;
		setBlue = 32;
		break;
	default:				//white
		setRed = 255;
		setGreen = 255;
		setBlue = 255;
		break;
	}
}
void PrintString(char chars[], u16 numChars, u16 start_x, u16 start_y, u8 frameNumber, u8 colorNumber)
{
	SetColor(colorNumber);
	for(int i = 0; i<numChars;i++)
	{
		PrintChar(chars[i], start_x+6*i, start_y, frameNumber, setRed, setGreen, setBlue);
	}
}

void Initialize()
{
	cursorPos_Y = 0;
	int Status;
	XAxiVdma_Config *vdmaConfig;
	int i;

	/*
	 * Initialize an array of pointers to the 3 frame buffers
	 */
	for (i = 0; i < DISPLAY_NUM_FRAMES; i++)
	{
		pFrames[i] = frameBuf[i];
	}

	/*
	 * Initialize a timer used for a simple delay
	 */
	TimerInitialize(SCU_TIMER_ID);

	/*
	 * Initialize VDMA driver
	 */
	vdmaConfig = XAxiVdma_LookupConfig(VGA_VDMA_ID);
	if (!vdmaConfig)
	{
		xil_printf("No video DMA found for ID %d\r\n", VGA_VDMA_ID);
		return;
	}
	Status = XAxiVdma_CfgInitialize(&vdma, vdmaConfig, vdmaConfig->BaseAddress);
	if (Status != XST_SUCCESS)
	{
		xil_printf("VDMA Configuration Initialization failed %d\r\n", Status);
		return;
	}

	/*
	 * Initialize the Display controller and start it
	 */
	Status = DisplayInitialize(&dispCtrl, &vdma, DISP_VTC_ID, DYNCLK_BASEADDR, pFrames, STRIDE);
	if (Status != XST_SUCCESS)
	{
		xil_printf("Display Ctrl initialization failed during demo initialization%d\r\n", Status);
		return;
	}

	Status = DisplayStart(&dispCtrl);
	if (Status != XST_SUCCESS)
	{
		xil_printf("Couldn't start display during demo initialization%d\r\n", Status);
		return;
	}

	//DemoPrintTest(dispCtrl.framePtr[dispCtrl.curFrame], dispCtrl.vMode.width, dispCtrl.vMode.height, dispCtrl.stride, DEMO_PATTERN_1);

	return;
}


void DemoRun()
{
	int nextFrame = 0;
	char userInput = 0;

	/* Flush UART FIFO */
	while (XUartPs_IsReceiveData(UART_BASEADDR))
	{
		XUartPs_ReadReg(UART_BASEADDR, XUARTPS_FIFO_OFFSET);
	}

	while (userInput != 'q')
	{
		DemoPrintMenu();

		/* Wait for data on UART */
		while (!XUartPs_IsReceiveData(UART_BASEADDR))
		{}

		/* Store the first character in the UART receive FIFO and echo it */
		if (XUartPs_IsReceiveData(UART_BASEADDR))
		{
			userInput = XUartPs_ReadReg(UART_BASEADDR, XUARTPS_FIFO_OFFSET);
			xil_printf("%c", userInput);
		}

		switch (userInput)
		{
		case '1':

			break;
		case '2':
			nextFrame = dispCtrl.curFrame + 1;
			if (nextFrame >= DISPLAY_NUM_FRAMES)
			{
				nextFrame = 0;
			}
			DisplayChangeFrame(&dispCtrl, nextFrame);
			break;
		case '3':
			break;
		case '4':
			break;
		case '5':
			DemoInvertFrame(dispCtrl.framePtr[dispCtrl.curFrame], dispCtrl.framePtr[dispCtrl.curFrame], dispCtrl.vMode.width, dispCtrl.vMode.height, dispCtrl.stride);
			break;
		case '6':
			/*
			nextFrame = dispCtrl.curFrame + 1;
			if (nextFrame >= DISPLAY_NUM_FRAMES)
			{
				nextFrame = 0;
			}
			DemoInvertFrame(dispCtrl.framePtr[dispCtrl.curFrame], dispCtrl.framePtr[nextFrame], dispCtrl.vMode.width, dispCtrl.vMode.height, dispCtrl.stride);
			DisplayChangeFrame(&dispCtrl, nextFrame);
			*/
			break;
		case '7':
			PrintChar('8', cursorPos_Y,0, dispCtrl.curFrame, 255, 255, 255);
			cursorPos_Y+=8;
			break;
		case '8':
			DrawRectangle(200,200, 200,200, 240, 240, 240, dispCtrl.curFrame);
			break;
		case 'q':
			break;
		default :
			xil_printf("\n\rInvalid Selection");
			TimerDelay(500000);
		}
	}

	return;
}

void DemoPrintMenu()
{
	xil_printf("\x1B[H"); //Set cursor to top left of terminal
	xil_printf("\x1B[2J"); //Clear terminal
	xil_printf("**************************************************\n\r");
	xil_printf("*               Arty Z7 HDMI Out Demo            *\n\r");
	xil_printf("**************************************************\n\r");
	xil_printf("*Display Resolution: %28s*\n\r", dispCtrl.vMode.label);
	printf("*Display Pixel Clock Freq. (MHz): %15.3f*\n\r", dispCtrl.pxlFreq);
	xil_printf("*Display Frame Index: %27d*\n\r", dispCtrl.curFrame);
	xil_printf("**************************************************\n\r");
	xil_printf("\n\r");
	xil_printf("1 - -\n\r");
	xil_printf("2 - Change Display Framebuffer Index\n\r");
	xil_printf("3 - -\n\r");
	xil_printf("4 - -\n\r");
	xil_printf("5 - Invert Current Frame colors\n\r");
	xil_printf("6 - Invert Current Frame colors seamlessly\n\r");
	xil_printf("7 - Print text\n\r");
	xil_printf("8 - Draw rectangle\n\r");
	xil_printf("q - Quit\n\r");
	xil_printf("\n\r");
	xil_printf("\n\r");
	xil_printf("Enter a selection:");
}

void CopyZeroFrameToOthers(u32 width, u32 height, u32 stride)
{


	u32 xcoi, ycoi;
	u32 lineStart = 0;
	u8 *srcFrame0 = dispCtrl.framePtr[0];
	u8 *destFrame1 = dispCtrl.framePtr[1];
	u8 *destFrame2 = dispCtrl.framePtr[2];

	//flush any pending writes
	//Xil_DCacheFlushRange((unsigned int) srcFrame0, MAX_FRAME);

	for(ycoi = 0; ycoi < height; ycoi++)
	{
		for(xcoi = 0; xcoi < (width * 3); xcoi+=3)
		{
			destFrame1[xcoi + lineStart] = srcFrame0[xcoi + lineStart];         //Red
			destFrame1[xcoi + lineStart + 1] = srcFrame0[xcoi + lineStart + 1]; //Blue
			destFrame1[xcoi + lineStart + 2] = srcFrame0[xcoi + lineStart + 2]; //Green
		}
		lineStart += stride;
	}

	lineStart = 0;
	for(ycoi = 0; ycoi < height; ycoi++)
	{
		for(xcoi = 0; xcoi < (width * 3); xcoi+=3)
		{
			destFrame2[xcoi + lineStart] = srcFrame0[xcoi + lineStart];         //Red
			destFrame2[xcoi + lineStart + 1] = srcFrame0[xcoi + lineStart + 1]; //Blue
			destFrame2[xcoi + lineStart + 2] = srcFrame0[xcoi + lineStart + 2]; //Green
		}
		lineStart += stride;
	}

	/*
	 * Flush the framebuffer memory range to ensure changes are written to the
	 * actual memory, and therefore accessible by the VDMA.
	 */
	Xil_DCacheFlushRange((unsigned int) destFrame1, MAX_FRAME);
	Xil_DCacheFlushRange((unsigned int) destFrame2, MAX_FRAME);
}

void DemoInvertFrame(u8 *srcFrame, u8 *destFrame, u32 width, u32 height, u32 stride)
{
	u32 xcoi, ycoi;
	u32 lineStart = 0;
	for(ycoi = 0; ycoi < height; ycoi++)
	{
		for(xcoi = 0; xcoi < (width * 3); xcoi+=3)
		{
			destFrame[xcoi + lineStart] = ~srcFrame[xcoi + lineStart];         //Red
			destFrame[xcoi + lineStart + 1] = ~srcFrame[xcoi + lineStart + 1]; //Blue
			destFrame[xcoi + lineStart + 2] = ~srcFrame[xcoi + lineStart + 2]; //Green
		}
		lineStart += stride;
	}
	/*
	 * Flush the framebuffer memory range to ensure changes are written to the
	 * actual memory, and therefore accessible by the VDMA.
	 */
	Xil_DCacheFlushRange((unsigned int) destFrame, MAX_FRAME);
}



/* UNUSED
void DemoChangeRes()
{
	int fResSet = 0;
	int status;
	char userInput = 0;

	// Flush UART FIFO
	while (XUartPs_IsReceiveData(UART_BASEADDR))
	{
		XUartPs_ReadReg(UART_BASEADDR, XUARTPS_FIFO_OFFSET);
	}

	while (!fResSet)
	{
		DemoCRMenu();

		// Wait for data on UART
		while (!XUartPs_IsReceiveData(UART_BASEADDR))
		{}

		// Store the first character in the UART recieve FIFO and echo it
		userInput = XUartPs_ReadReg(UART_BASEADDR, XUARTPS_FIFO_OFFSET);
		xil_printf("%c", userInput);
		status = XST_SUCCESS;
		switch (userInput)
		{
		case '1':
			status = DisplayStop(&dispCtrl);
			DisplaySetMode(&dispCtrl, &VMODE_640x480);
			DisplayStart(&dispCtrl);
			fResSet = 1;
			break;
		case '2':
			status = DisplayStop(&dispCtrl);
			DisplaySetMode(&dispCtrl, &VMODE_800x600);
			DisplayStart(&dispCtrl);
			fResSet = 1;
			break;
		case '3':
			status = DisplayStop(&dispCtrl);
			DisplaySetMode(&dispCtrl, &VMODE_1280x720);
			DisplayStart(&dispCtrl);
			fResSet = 1;
			break;
		case '4':
			status = DisplayStop(&dispCtrl);
			DisplaySetMode(&dispCtrl, &VMODE_1280x1024);
			DisplayStart(&dispCtrl);
			fResSet = 1;
			break;
		case '5':
			status = DisplayStop(&dispCtrl);
			DisplaySetMode(&dispCtrl, &VMODE_1920x1080);
			DisplayStart(&dispCtrl);
			fResSet = 1;
			break;
		case 'q':
			fResSet = 1;
			break;
		default :
			xil_printf("\n\rInvalid Selection");
			TimerDelay(500000);
		}
		if (status == XST_DMA_ERROR)
		{
			xil_printf("\n\rWARNING: AXI VDMA Error detected and cleared\n\r");
		}
	}
}

void DemoPrintTest(u8 *frame, u32 width, u32 height, u32 stride, int pattern)
{
	u32 xcoi, ycoi;
	u32 iPixelAddr;
	u8 wRed, wBlue, wGreen;
	u32 wCurrentInt;
	double fRed, fBlue, fGreen, fColor;
	u32 xLeft, xMid, xRight, xInt;
	u32 yMid, yInt;
	double xInc, yInc;


	switch (pattern)
	{
	case DEMO_PATTERN_0:

		xInt = width / 4; //Four intervals, each with width/4 pixels
		xLeft = xInt * 3;
		xMid = xInt * 2 * 3;
		xRight = xInt * 3 * 3;
		xInc = 256.0 / ((double) xInt); //256 color intensities are cycled through per interval (overflow must be caught when color=256.0)

		yInt = height / 2; //Two intervals, each with width/2 lines
		yMid = yInt;
		yInc = 256.0 / ((double) yInt); //256 color intensities are cycled through per interval (overflow must be caught when color=256.0)

		fBlue = 0.0;
		fRed = 256.0;
		for(xcoi = 0; xcoi < (width*3); xcoi+=3)
		{
			// Convert color intensities to integers < 256, and trim values >=256
			wRed = (fRed >= 256.0) ? 255 : ((u8) fRed);
			wBlue = (fBlue >= 256.0) ? 255 : ((u8) fBlue);
			iPixelAddr = xcoi;
			fGreen = 0.0;
			for(ycoi = 0; ycoi < height; ycoi++)
			{

				wGreen = (fGreen >= 256.0) ? 255 : ((u8) fGreen);
				frame[iPixelAddr] = wRed;
				frame[iPixelAddr + 1] = wBlue;
				frame[iPixelAddr + 2] = wGreen;
				if (ycoi < yMid)
				{
					fGreen += yInc;
				}
				else
				{
					fGreen -= yInc;
				}

				 // This pattern is printed one vertical line at a time, so the address must be incremented
				 // by the stride instead of just 1.
				iPixelAddr += stride;
			}

			if (xcoi < xLeft)
			{
				fBlue = 0.0;
				fRed -= xInc;
			}
			else if (xcoi < xMid)
			{
				fBlue += xInc;
				fRed += xInc;
			}
			else if (xcoi < xRight)
			{
				fBlue -= xInc;
				fRed -= xInc;
			}
			else
			{
				fBlue += xInc;
				fRed = 0;
			}
		}
		 // Flush the framebuffer memory range to ensure changes are written to the
		 // actual memory, and therefore accessible by the VDMA.
		Xil_DCacheFlushRange((unsigned int) frame, MAX_FRAME);
		break;
	case DEMO_PATTERN_1:

		xInt = width / 7; //Seven intervals, each with width/7 pixels
		xInc = 256.0 / ((double) xInt); //256 color intensities per interval. Notice that overflow is handled for this pattern.

		fColor = 0.0;
		wCurrentInt = 1;
		for(xcoi = 0; xcoi < (width*3); xcoi+=3)
		{
			 // Just draw white in the last partial interval (when width is not divisible by 7)
			if (wCurrentInt > 7)
			{
				wRed = 255;
				wBlue = 255;
				wGreen = 255;
			}
			else
			{
				if (wCurrentInt & 0b001)
					wRed = (u8) fColor;
				else
					wRed = 0;

				if (wCurrentInt & 0b010)
					wBlue = (u8) fColor;
				else
					wBlue = 0;

				if (wCurrentInt & 0b100)
					wGreen = (u8) fColor;
				else
					wGreen = 0;
			}

			iPixelAddr = xcoi;

			for(ycoi = 0; ycoi < height; ycoi++)
			{
				frame[iPixelAddr] = wRed;
				frame[iPixelAddr + 1] = wBlue;
				frame[iPixelAddr + 2] = wGreen;

				 // This pattern is printed one vertical line at a time, so the address must be incremented
				 // by the stride instead of just 1.

				iPixelAddr += stride;
			}

			fColor += xInc;
			if (fColor >= 256.0)
			{
				fColor = 0.0;
				wCurrentInt++;
			}
		}

		 // Flush the framebuffer memory range to ensure changes are written to the
		 // actual memory, and therefore accessible by the VDMA.

		Xil_DCacheFlushRange((unsigned int) frame, MAX_FRAME);
		break;
	default :
		xil_printf("Error: invalid pattern passed to DemoPrintTest");
	}
}

void DemoCRMenu()
{
	xil_printf("\x1B[H"); //Set cursor to top left of terminal
	xil_printf("\x1B[2J"); //Clear terminal
	xil_printf("**************************************************\n\r");
	xil_printf("*               Arty Z7 HDMI Out Demo            *\n\r");
	xil_printf("**************************************************\n\r");
	xil_printf("*Current Resolution: %28s*\n\r", dispCtrl.vMode.label);
	printf("*Pixel Clock Freq. (MHz): %23.3f*\n\r", dispCtrl.pxlFreq);
	xil_printf("**************************************************\n\r");
	xil_printf("\n\r");
	xil_printf("1 - %s\n\r", VMODE_640x480.label);
	xil_printf("2 - %s\n\r", VMODE_800x600.label);
	xil_printf("3 - %s\n\r", VMODE_1280x720.label);
	xil_printf("4 - %s\n\r", VMODE_1280x1024.label);
	xil_printf("5 - %s\n\r", VMODE_1920x1080.label);
	xil_printf("q - Quit (don't change resolution)\n\r");
	xil_printf("\n\r");
	xil_printf("Select a new resolution:");
}

*/
