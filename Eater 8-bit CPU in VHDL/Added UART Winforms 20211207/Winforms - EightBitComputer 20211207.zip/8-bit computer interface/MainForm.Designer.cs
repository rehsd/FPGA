﻿
namespace EightBitInterface
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ConnectButton = new System.Windows.Forms.Button();
            this.PortsCombo = new System.Windows.Forms.ComboBox();
            this.CommandTextbox = new System.Windows.Forms.TextBox();
            this.SendButton = new System.Windows.Forms.Button();
            this.OutputRichtext = new System.Windows.Forms.RichTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label38 = new System.Windows.Forms.Label();
            this.loadSetCombo = new System.Windows.Forms.ComboBox();
            this.code1001 = new System.Windows.Forms.Label();
            this.code1010 = new System.Windows.Forms.Label();
            this.code1011 = new System.Windows.Forms.Label();
            this.code1100 = new System.Windows.Forms.Label();
            this.code1101 = new System.Windows.Forms.Label();
            this.code1110 = new System.Windows.Forms.Label();
            this.code1111 = new System.Windows.Forms.Label();
            this.code1000 = new System.Windows.Forms.Label();
            this.code0001 = new System.Windows.Forms.Label();
            this.code0010 = new System.Windows.Forms.Label();
            this.code0011 = new System.Windows.Forms.Label();
            this.code0100 = new System.Windows.Forms.Label();
            this.code0101 = new System.Windows.Forms.Label();
            this.code0110 = new System.Windows.Forms.Label();
            this.code0111 = new System.Windows.Forms.Label();
            this.code0000 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.ProgramRAMButton = new System.Windows.Forms.Button();
            this.Mem1001 = new System.Windows.Forms.TextBox();
            this.Mem1010 = new System.Windows.Forms.TextBox();
            this.Mem1011 = new System.Windows.Forms.TextBox();
            this.Mem1100 = new System.Windows.Forms.TextBox();
            this.Mem1101 = new System.Windows.Forms.TextBox();
            this.Mem1110 = new System.Windows.Forms.TextBox();
            this.Mem1111 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.Mem1000 = new System.Windows.Forms.TextBox();
            this.Mem0001 = new System.Windows.Forms.TextBox();
            this.Mem0010 = new System.Windows.Forms.TextBox();
            this.Mem0011 = new System.Windows.Forms.TextBox();
            this.Mem0100 = new System.Windows.Forms.TextBox();
            this.Mem0101 = new System.Windows.Forms.TextBox();
            this.Mem0110 = new System.Windows.Forms.TextBox();
            this.Mem0111 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.Mem0000 = new System.Windows.Forms.TextBox();
            this.connectionStatusPictureBox = new System.Windows.Forms.PictureBox();
            this.AboutButton = new System.Windows.Forms.Button();
            this.displayLogCheckBox = new System.Windows.Forms.CheckBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.connectionSpeedLabel = new System.Windows.Forms.Label();
            this.ReadRAMButton = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.connectionStatusPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // ConnectButton
            // 
            this.ConnectButton.Enabled = false;
            this.ConnectButton.Location = new System.Drawing.Point(364, 14);
            this.ConnectButton.Margin = new System.Windows.Forms.Padding(1);
            this.ConnectButton.Name = "ConnectButton";
            this.ConnectButton.Size = new System.Drawing.Size(120, 35);
            this.ConnectButton.TabIndex = 1;
            this.ConnectButton.Text = "&Connect";
            this.ConnectButton.UseVisualStyleBackColor = true;
            this.ConnectButton.Click += new System.EventHandler(this.ConnectButton_Click);
            // 
            // PortsCombo
            // 
            this.PortsCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PortsCombo.FormattingEnabled = true;
            this.PortsCombo.Location = new System.Drawing.Point(61, 14);
            this.PortsCombo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.PortsCombo.Name = "PortsCombo";
            this.PortsCombo.Size = new System.Drawing.Size(291, 33);
            this.PortsCombo.TabIndex = 0;
            this.PortsCombo.SelectedIndexChanged += new System.EventHandler(this.PortsCombo_SelectedIndexChanged);
            // 
            // CommandTextbox
            // 
            this.CommandTextbox.Location = new System.Drawing.Point(256, 968);
            this.CommandTextbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CommandTextbox.Name = "CommandTextbox";
            this.CommandTextbox.Size = new System.Drawing.Size(333, 31);
            this.CommandTextbox.TabIndex = 5;
            // 
            // SendButton
            // 
            this.SendButton.Location = new System.Drawing.Point(601, 963);
            this.SendButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.SendButton.Name = "SendButton";
            this.SendButton.Size = new System.Drawing.Size(86, 39);
            this.SendButton.TabIndex = 6;
            this.SendButton.Text = "&Send";
            this.SendButton.UseVisualStyleBackColor = true;
            this.SendButton.Click += new System.EventHandler(this.SendButton_Click);
            // 
            // OutputRichtext
            // 
            this.OutputRichtext.Location = new System.Drawing.Point(19, 111);
            this.OutputRichtext.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutputRichtext.Name = "OutputRichtext";
            this.OutputRichtext.Size = new System.Drawing.Size(670, 834);
            this.OutputRichtext.TabIndex = 24;
            this.OutputRichtext.Text = "";
            this.OutputRichtext.TextChanged += new System.EventHandler(this.OutputRichtext_TextChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label38);
            this.groupBox2.Controls.Add(this.loadSetCombo);
            this.groupBox2.Controls.Add(this.code1001);
            this.groupBox2.Controls.Add(this.code1010);
            this.groupBox2.Controls.Add(this.code1011);
            this.groupBox2.Controls.Add(this.code1100);
            this.groupBox2.Controls.Add(this.code1101);
            this.groupBox2.Controls.Add(this.code1110);
            this.groupBox2.Controls.Add(this.code1111);
            this.groupBox2.Controls.Add(this.code1000);
            this.groupBox2.Controls.Add(this.code0001);
            this.groupBox2.Controls.Add(this.code0010);
            this.groupBox2.Controls.Add(this.code0011);
            this.groupBox2.Controls.Add(this.code0100);
            this.groupBox2.Controls.Add(this.code0101);
            this.groupBox2.Controls.Add(this.code0110);
            this.groupBox2.Controls.Add(this.code0111);
            this.groupBox2.Controls.Add(this.code0000);
            this.groupBox2.Controls.Add(this.label36);
            this.groupBox2.Controls.Add(this.ProgramRAMButton);
            this.groupBox2.Controls.Add(this.Mem1001);
            this.groupBox2.Controls.Add(this.Mem1010);
            this.groupBox2.Controls.Add(this.Mem1011);
            this.groupBox2.Controls.Add(this.Mem1100);
            this.groupBox2.Controls.Add(this.Mem1101);
            this.groupBox2.Controls.Add(this.Mem1110);
            this.groupBox2.Controls.Add(this.Mem1111);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.label34);
            this.groupBox2.Controls.Add(this.label35);
            this.groupBox2.Controls.Add(this.Mem1000);
            this.groupBox2.Controls.Add(this.Mem0001);
            this.groupBox2.Controls.Add(this.Mem0010);
            this.groupBox2.Controls.Add(this.Mem0011);
            this.groupBox2.Controls.Add(this.Mem0100);
            this.groupBox2.Controls.Add(this.Mem0101);
            this.groupBox2.Controls.Add(this.Mem0110);
            this.groupBox2.Controls.Add(this.Mem0111);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.Mem0000);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox2.Location = new System.Drawing.Point(717, 301);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Size = new System.Drawing.Size(680, 536);
            this.groupBox2.TabIndex = 25;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Program (Populate RAM)";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label38.Location = new System.Drawing.Point(379, 0);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(42, 19);
            this.label38.TabIndex = 58;
            this.label38.Text = "Load:";
            // 
            // loadSetCombo
            // 
            this.loadSetCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.loadSetCombo.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.loadSetCombo.FormattingEnabled = true;
            this.loadSetCombo.Location = new System.Drawing.Point(430, 0);
            this.loadSetCombo.Margin = new System.Windows.Forms.Padding(1);
            this.loadSetCombo.Name = "loadSetCombo";
            this.loadSetCombo.Size = new System.Drawing.Size(205, 27);
            this.loadSetCombo.TabIndex = 57;
            this.loadSetCombo.SelectedIndexChanged += new System.EventHandler(this.loadSetCombo_SelectedIndexChanged);
            // 
            // code1001
            // 
            this.code1001.AutoSize = true;
            this.code1001.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.code1001.ForeColor = System.Drawing.Color.Blue;
            this.code1001.Location = new System.Drawing.Point(458, 130);
            this.code1001.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.code1001.Name = "code1001";
            this.code1001.Size = new System.Drawing.Size(41, 19);
            this.code1001.TabIndex = 56;
            this.code1001.Text = "0000";
            this.code1001.Click += new System.EventHandler(this.code1001_Click);
            // 
            // code1010
            // 
            this.code1010.AutoSize = true;
            this.code1010.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.code1010.ForeColor = System.Drawing.Color.Blue;
            this.code1010.Location = new System.Drawing.Point(458, 181);
            this.code1010.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.code1010.Name = "code1010";
            this.code1010.Size = new System.Drawing.Size(41, 19);
            this.code1010.TabIndex = 55;
            this.code1010.Text = "0000";
            this.code1010.Click += new System.EventHandler(this.code1010_Click);
            // 
            // code1011
            // 
            this.code1011.AutoSize = true;
            this.code1011.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.code1011.ForeColor = System.Drawing.Color.Blue;
            this.code1011.Location = new System.Drawing.Point(458, 224);
            this.code1011.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.code1011.Name = "code1011";
            this.code1011.Size = new System.Drawing.Size(41, 19);
            this.code1011.TabIndex = 54;
            this.code1011.Text = "0000";
            this.code1011.Click += new System.EventHandler(this.code1011_Click);
            // 
            // code1100
            // 
            this.code1100.AutoSize = true;
            this.code1100.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.code1100.ForeColor = System.Drawing.Color.Blue;
            this.code1100.Location = new System.Drawing.Point(458, 274);
            this.code1100.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.code1100.Name = "code1100";
            this.code1100.Size = new System.Drawing.Size(41, 19);
            this.code1100.TabIndex = 53;
            this.code1100.Text = "0000";
            this.code1100.Click += new System.EventHandler(this.code1100_Click);
            // 
            // code1101
            // 
            this.code1101.AutoSize = true;
            this.code1101.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.code1101.ForeColor = System.Drawing.Color.Blue;
            this.code1101.Location = new System.Drawing.Point(458, 321);
            this.code1101.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.code1101.Name = "code1101";
            this.code1101.Size = new System.Drawing.Size(41, 19);
            this.code1101.TabIndex = 52;
            this.code1101.Text = "0000";
            this.code1101.Click += new System.EventHandler(this.code1101_Click);
            // 
            // code1110
            // 
            this.code1110.AutoSize = true;
            this.code1110.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.code1110.ForeColor = System.Drawing.Color.Blue;
            this.code1110.Location = new System.Drawing.Point(458, 369);
            this.code1110.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.code1110.Name = "code1110";
            this.code1110.Size = new System.Drawing.Size(41, 19);
            this.code1110.TabIndex = 51;
            this.code1110.Text = "0000";
            this.code1110.Click += new System.EventHandler(this.code1110_Click);
            // 
            // code1111
            // 
            this.code1111.AutoSize = true;
            this.code1111.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.code1111.ForeColor = System.Drawing.Color.Blue;
            this.code1111.Location = new System.Drawing.Point(458, 415);
            this.code1111.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.code1111.Name = "code1111";
            this.code1111.Size = new System.Drawing.Size(41, 19);
            this.code1111.TabIndex = 50;
            this.code1111.Text = "0000";
            this.code1111.Click += new System.EventHandler(this.code1111_Click);
            // 
            // code1000
            // 
            this.code1000.AutoSize = true;
            this.code1000.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.code1000.ForeColor = System.Drawing.Color.Blue;
            this.code1000.Location = new System.Drawing.Point(458, 89);
            this.code1000.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.code1000.Name = "code1000";
            this.code1000.Size = new System.Drawing.Size(41, 19);
            this.code1000.TabIndex = 49;
            this.code1000.Text = "0000";
            this.code1000.Click += new System.EventHandler(this.code1000_Click);
            // 
            // code0001
            // 
            this.code0001.AutoSize = true;
            this.code0001.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.code0001.ForeColor = System.Drawing.Color.Blue;
            this.code0001.Location = new System.Drawing.Point(199, 126);
            this.code0001.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.code0001.Name = "code0001";
            this.code0001.Size = new System.Drawing.Size(41, 19);
            this.code0001.TabIndex = 48;
            this.code0001.Text = "0000";
            this.code0001.Click += new System.EventHandler(this.code0001_Click);
            // 
            // code0010
            // 
            this.code0010.AutoSize = true;
            this.code0010.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.code0010.ForeColor = System.Drawing.Color.Blue;
            this.code0010.Location = new System.Drawing.Point(199, 179);
            this.code0010.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.code0010.Name = "code0010";
            this.code0010.Size = new System.Drawing.Size(41, 19);
            this.code0010.TabIndex = 47;
            this.code0010.Text = "0000";
            this.code0010.Click += new System.EventHandler(this.code0010_Click);
            // 
            // code0011
            // 
            this.code0011.AutoSize = true;
            this.code0011.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.code0011.ForeColor = System.Drawing.Color.Blue;
            this.code0011.Location = new System.Drawing.Point(199, 220);
            this.code0011.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.code0011.Name = "code0011";
            this.code0011.Size = new System.Drawing.Size(41, 19);
            this.code0011.TabIndex = 46;
            this.code0011.Text = "0000";
            this.code0011.Click += new System.EventHandler(this.code0011_Click);
            // 
            // code0100
            // 
            this.code0100.AutoSize = true;
            this.code0100.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.code0100.ForeColor = System.Drawing.Color.Blue;
            this.code0100.Location = new System.Drawing.Point(199, 270);
            this.code0100.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.code0100.Name = "code0100";
            this.code0100.Size = new System.Drawing.Size(41, 19);
            this.code0100.TabIndex = 45;
            this.code0100.Text = "0000";
            this.code0100.Click += new System.EventHandler(this.code0100_Click);
            // 
            // code0101
            // 
            this.code0101.AutoSize = true;
            this.code0101.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.code0101.ForeColor = System.Drawing.Color.Blue;
            this.code0101.Location = new System.Drawing.Point(199, 319);
            this.code0101.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.code0101.Name = "code0101";
            this.code0101.Size = new System.Drawing.Size(41, 19);
            this.code0101.TabIndex = 44;
            this.code0101.Text = "0000";
            this.code0101.Click += new System.EventHandler(this.code0101_Click);
            // 
            // code0110
            // 
            this.code0110.AutoSize = true;
            this.code0110.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.code0110.ForeColor = System.Drawing.Color.Blue;
            this.code0110.Location = new System.Drawing.Point(199, 365);
            this.code0110.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.code0110.Name = "code0110";
            this.code0110.Size = new System.Drawing.Size(41, 19);
            this.code0110.TabIndex = 43;
            this.code0110.Text = "0000";
            this.code0110.Click += new System.EventHandler(this.code0110_Click);
            // 
            // code0111
            // 
            this.code0111.AutoSize = true;
            this.code0111.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.code0111.ForeColor = System.Drawing.Color.Blue;
            this.code0111.Location = new System.Drawing.Point(199, 411);
            this.code0111.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.code0111.Name = "code0111";
            this.code0111.Size = new System.Drawing.Size(41, 19);
            this.code0111.TabIndex = 42;
            this.code0111.Text = "0000";
            this.code0111.Click += new System.EventHandler(this.code0111_Click);
            // 
            // code0000
            // 
            this.code0000.AutoSize = true;
            this.code0000.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.code0000.ForeColor = System.Drawing.Color.Blue;
            this.code0000.Location = new System.Drawing.Point(199, 85);
            this.code0000.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.code0000.Name = "code0000";
            this.code0000.Size = new System.Drawing.Size(41, 19);
            this.code0000.TabIndex = 40;
            this.code0000.Text = "0000";
            this.code0000.Click += new System.EventHandler(this.code0000_Click);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.ForeColor = System.Drawing.Color.DimGray;
            this.label36.Location = new System.Drawing.Point(555, 52);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(110, 425);
            this.label36.TabIndex = 39;
            this.label36.Text = "Op Codes\r\n\r\n0001    LDA\r\n0010    ADD\r\n0011    SUB\r\n0100    STA\r\n0101    LDI\r\n0110" +
    "    JMP\r\n0111    JC\r\n1000    JZ\r\n1001     -\r\n1010     -\r\n1011     -\r\n1100     -\r" +
    "\n1101     -\r\n1110    OUT\r\n1111    HLT";
            // 
            // ProgramRAMButton
            // 
            this.ProgramRAMButton.Location = new System.Drawing.Point(31, 474);
            this.ProgramRAMButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ProgramRAMButton.Name = "ProgramRAMButton";
            this.ProgramRAMButton.Size = new System.Drawing.Size(461, 39);
            this.ProgramRAMButton.TabIndex = 23;
            this.ProgramRAMButton.Text = "&Program RAM";
            this.ProgramRAMButton.UseVisualStyleBackColor = true;
            this.ProgramRAMButton.Click += new System.EventHandler(this.ProgramRAMButton_Click);
            // 
            // Mem1001
            // 
            this.Mem1001.Location = new System.Drawing.Point(359, 126);
            this.Mem1001.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Mem1001.MaxLength = 8;
            this.Mem1001.Name = "Mem1001";
            this.Mem1001.Size = new System.Drawing.Size(90, 31);
            this.Mem1001.TabIndex = 16;
            this.Mem1001.Text = "?";
            this.Mem1001.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Mem1001.TextChanged += new System.EventHandler(this.Mem1001_TextChanged);
            this.Mem1001.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemXXXX_KeyPress);
            this.Mem1001.Leave += new System.EventHandler(this.MemXXXX_Leave);
            // 
            // Mem1010
            // 
            this.Mem1010.Location = new System.Drawing.Point(359, 174);
            this.Mem1010.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Mem1010.MaxLength = 8;
            this.Mem1010.Name = "Mem1010";
            this.Mem1010.Size = new System.Drawing.Size(90, 31);
            this.Mem1010.TabIndex = 17;
            this.Mem1010.Text = "?";
            this.Mem1010.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Mem1010.TextChanged += new System.EventHandler(this.Mem1010_TextChanged);
            this.Mem1010.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemXXXX_KeyPress);
            this.Mem1010.Leave += new System.EventHandler(this.MemXXXX_Leave);
            // 
            // Mem1011
            // 
            this.Mem1011.Location = new System.Drawing.Point(359, 220);
            this.Mem1011.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Mem1011.MaxLength = 8;
            this.Mem1011.Name = "Mem1011";
            this.Mem1011.Size = new System.Drawing.Size(90, 31);
            this.Mem1011.TabIndex = 18;
            this.Mem1011.Text = "?";
            this.Mem1011.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Mem1011.TextChanged += new System.EventHandler(this.Mem1011_TextChanged);
            this.Mem1011.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemXXXX_KeyPress);
            this.Mem1011.Leave += new System.EventHandler(this.MemXXXX_Leave);
            // 
            // Mem1100
            // 
            this.Mem1100.Location = new System.Drawing.Point(359, 266);
            this.Mem1100.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Mem1100.MaxLength = 8;
            this.Mem1100.Name = "Mem1100";
            this.Mem1100.Size = new System.Drawing.Size(90, 31);
            this.Mem1100.TabIndex = 19;
            this.Mem1100.Text = "?";
            this.Mem1100.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Mem1100.TextChanged += new System.EventHandler(this.Mem1100_TextChanged);
            this.Mem1100.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemXXXX_KeyPress);
            this.Mem1100.Leave += new System.EventHandler(this.MemXXXX_Leave);
            // 
            // Mem1101
            // 
            this.Mem1101.Location = new System.Drawing.Point(359, 314);
            this.Mem1101.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Mem1101.MaxLength = 8;
            this.Mem1101.Name = "Mem1101";
            this.Mem1101.Size = new System.Drawing.Size(90, 31);
            this.Mem1101.TabIndex = 20;
            this.Mem1101.Text = "?";
            this.Mem1101.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Mem1101.TextChanged += new System.EventHandler(this.Mem1101_TextChanged);
            this.Mem1101.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemXXXX_KeyPress);
            this.Mem1101.Leave += new System.EventHandler(this.MemXXXX_Leave);
            // 
            // Mem1110
            // 
            this.Mem1110.Location = new System.Drawing.Point(359, 360);
            this.Mem1110.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Mem1110.MaxLength = 8;
            this.Mem1110.Name = "Mem1110";
            this.Mem1110.Size = new System.Drawing.Size(90, 31);
            this.Mem1110.TabIndex = 21;
            this.Mem1110.Text = "?";
            this.Mem1110.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Mem1110.TextChanged += new System.EventHandler(this.Mem1110_TextChanged);
            this.Mem1110.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemXXXX_KeyPress);
            this.Mem1110.Leave += new System.EventHandler(this.MemXXXX_Leave);
            // 
            // Mem1111
            // 
            this.Mem1111.Location = new System.Drawing.Point(359, 406);
            this.Mem1111.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Mem1111.MaxLength = 8;
            this.Mem1111.Name = "Mem1111";
            this.Mem1111.Size = new System.Drawing.Size(90, 31);
            this.Mem1111.TabIndex = 22;
            this.Mem1111.Text = "?";
            this.Mem1111.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Mem1111.TextChanged += new System.EventHandler(this.Mem1111_TextChanged);
            this.Mem1111.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemXXXX_KeyPress);
            this.Mem1111.Leave += new System.EventHandler(this.MemXXXX_Leave);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(359, 41);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(104, 25);
            this.label19.TabIndex = 30;
            this.label19.Text = "Value to set";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(290, 131);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(52, 25);
            this.label27.TabIndex = 29;
            this.label27.Text = "1001";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(290, 179);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(52, 25);
            this.label28.TabIndex = 28;
            this.label28.Text = "1010";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(290, 225);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(52, 25);
            this.label29.TabIndex = 27;
            this.label29.Text = "1011";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(290, 271);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(52, 25);
            this.label30.TabIndex = 26;
            this.label30.Text = "1100";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(290, 319);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(52, 25);
            this.label31.TabIndex = 25;
            this.label31.Text = "1101";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(290, 365);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(52, 25);
            this.label32.TabIndex = 24;
            this.label32.Text = "1110";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(290, 411);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(52, 25);
            this.label33.TabIndex = 23;
            this.label33.Text = "1111";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(271, 41);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(77, 25);
            this.label34.TabIndex = 22;
            this.label34.Text = "Address";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(290, 85);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(52, 25);
            this.label35.TabIndex = 21;
            this.label35.Text = "1000";
            // 
            // Mem1000
            // 
            this.Mem1000.Location = new System.Drawing.Point(359, 80);
            this.Mem1000.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Mem1000.MaxLength = 8;
            this.Mem1000.Name = "Mem1000";
            this.Mem1000.Size = new System.Drawing.Size(90, 31);
            this.Mem1000.TabIndex = 15;
            this.Mem1000.Text = "?";
            this.Mem1000.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Mem1000.TextChanged += new System.EventHandler(this.Mem1000_TextChanged);
            this.Mem1000.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemXXXX_KeyPress);
            this.Mem1000.Leave += new System.EventHandler(this.MemXXXX_Leave);
            // 
            // Mem0001
            // 
            this.Mem0001.Location = new System.Drawing.Point(100, 126);
            this.Mem0001.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Mem0001.MaxLength = 8;
            this.Mem0001.Name = "Mem0001";
            this.Mem0001.Size = new System.Drawing.Size(90, 31);
            this.Mem0001.TabIndex = 8;
            this.Mem0001.Text = "?";
            this.Mem0001.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Mem0001.TextChanged += new System.EventHandler(this.Mem0001_TextChanged);
            this.Mem0001.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemXXXX_KeyPress);
            this.Mem0001.Leave += new System.EventHandler(this.MemXXXX_Leave);
            // 
            // Mem0010
            // 
            this.Mem0010.Location = new System.Drawing.Point(100, 174);
            this.Mem0010.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Mem0010.MaxLength = 8;
            this.Mem0010.Name = "Mem0010";
            this.Mem0010.Size = new System.Drawing.Size(90, 31);
            this.Mem0010.TabIndex = 9;
            this.Mem0010.Text = "?";
            this.Mem0010.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Mem0010.TextChanged += new System.EventHandler(this.Mem0010_TextChanged);
            this.Mem0010.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemXXXX_KeyPress);
            this.Mem0010.Leave += new System.EventHandler(this.MemXXXX_Leave);
            // 
            // Mem0011
            // 
            this.Mem0011.Location = new System.Drawing.Point(100, 220);
            this.Mem0011.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Mem0011.MaxLength = 8;
            this.Mem0011.Name = "Mem0011";
            this.Mem0011.Size = new System.Drawing.Size(90, 31);
            this.Mem0011.TabIndex = 10;
            this.Mem0011.Text = "?";
            this.Mem0011.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Mem0011.TextChanged += new System.EventHandler(this.Mem011_TextChanged);
            this.Mem0011.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemXXXX_KeyPress);
            this.Mem0011.Leave += new System.EventHandler(this.MemXXXX_Leave);
            // 
            // Mem0100
            // 
            this.Mem0100.Location = new System.Drawing.Point(100, 266);
            this.Mem0100.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Mem0100.MaxLength = 8;
            this.Mem0100.Name = "Mem0100";
            this.Mem0100.Size = new System.Drawing.Size(90, 31);
            this.Mem0100.TabIndex = 11;
            this.Mem0100.Text = "?";
            this.Mem0100.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Mem0100.TextChanged += new System.EventHandler(this.Mem0100_TextChanged);
            this.Mem0100.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemXXXX_KeyPress);
            this.Mem0100.Leave += new System.EventHandler(this.MemXXXX_Leave);
            // 
            // Mem0101
            // 
            this.Mem0101.Location = new System.Drawing.Point(100, 314);
            this.Mem0101.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Mem0101.MaxLength = 8;
            this.Mem0101.Name = "Mem0101";
            this.Mem0101.Size = new System.Drawing.Size(90, 31);
            this.Mem0101.TabIndex = 12;
            this.Mem0101.Text = "?";
            this.Mem0101.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Mem0101.TextChanged += new System.EventHandler(this.Mem0101_TextChanged);
            this.Mem0101.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemXXXX_KeyPress);
            this.Mem0101.Leave += new System.EventHandler(this.MemXXXX_Leave);
            // 
            // Mem0110
            // 
            this.Mem0110.Location = new System.Drawing.Point(100, 360);
            this.Mem0110.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Mem0110.MaxLength = 8;
            this.Mem0110.Name = "Mem0110";
            this.Mem0110.Size = new System.Drawing.Size(90, 31);
            this.Mem0110.TabIndex = 13;
            this.Mem0110.Text = "?";
            this.Mem0110.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Mem0110.TextChanged += new System.EventHandler(this.Mem0110_TextChanged);
            this.Mem0110.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemXXXX_KeyPress);
            this.Mem0110.Leave += new System.EventHandler(this.MemXXXX_Leave);
            // 
            // Mem0111
            // 
            this.Mem0111.Location = new System.Drawing.Point(100, 406);
            this.Mem0111.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Mem0111.MaxLength = 8;
            this.Mem0111.Name = "Mem0111";
            this.Mem0111.Size = new System.Drawing.Size(90, 31);
            this.Mem0111.TabIndex = 14;
            this.Mem0111.Text = "?";
            this.Mem0111.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Mem0111.TextChanged += new System.EventHandler(this.Mem0111_TextChanged);
            this.Mem0111.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemXXXX_KeyPress);
            this.Mem0111.Leave += new System.EventHandler(this.MemXXXX_Leave);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(100, 41);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(104, 25);
            this.label18.TabIndex = 12;
            this.label18.Text = "Value to set";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(31, 131);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(52, 25);
            this.label26.TabIndex = 11;
            this.label26.Text = "0001";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(31, 179);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(52, 25);
            this.label25.TabIndex = 10;
            this.label25.Text = "0010";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(31, 225);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(52, 25);
            this.label24.TabIndex = 9;
            this.label24.Text = "0011";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(31, 271);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(52, 25);
            this.label23.TabIndex = 8;
            this.label23.Text = "0100";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(31, 319);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(52, 25);
            this.label22.TabIndex = 7;
            this.label22.Text = "0101";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(31, 365);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(52, 25);
            this.label21.TabIndex = 6;
            this.label21.Text = "0110";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(31, 411);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(52, 25);
            this.label20.TabIndex = 5;
            this.label20.Text = "0111";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(12, 41);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(77, 25);
            this.label17.TabIndex = 2;
            this.label17.Text = "Address";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(31, 85);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(52, 25);
            this.label16.TabIndex = 1;
            this.label16.Text = "0000";
            // 
            // Mem0000
            // 
            this.Mem0000.Location = new System.Drawing.Point(100, 80);
            this.Mem0000.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Mem0000.MaxLength = 8;
            this.Mem0000.Name = "Mem0000";
            this.Mem0000.Size = new System.Drawing.Size(90, 31);
            this.Mem0000.TabIndex = 7;
            this.Mem0000.Text = "?";
            this.Mem0000.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Mem0000.TextChanged += new System.EventHandler(this.Mem0000_TextChanged);
            this.Mem0000.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MemXXXX_KeyPress);
            this.Mem0000.Leave += new System.EventHandler(this.MemXXXX_Leave);
            // 
            // connectionStatusPictureBox
            // 
            this.connectionStatusPictureBox.BackColor = System.Drawing.Color.Red;
            this.connectionStatusPictureBox.Location = new System.Drawing.Point(488, 16);
            this.connectionStatusPictureBox.Margin = new System.Windows.Forms.Padding(1);
            this.connectionStatusPictureBox.Name = "connectionStatusPictureBox";
            this.connectionStatusPictureBox.Size = new System.Drawing.Size(30, 30);
            this.connectionStatusPictureBox.TabIndex = 26;
            this.connectionStatusPictureBox.TabStop = false;
            // 
            // AboutButton
            // 
            this.AboutButton.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AboutButton.Location = new System.Drawing.Point(1316, 9);
            this.AboutButton.Margin = new System.Windows.Forms.Padding(4);
            this.AboutButton.Name = "AboutButton";
            this.AboutButton.Size = new System.Drawing.Size(84, 29);
            this.AboutButton.TabIndex = 27;
            this.AboutButton.Text = "&About";
            this.AboutButton.UseVisualStyleBackColor = true;
            this.AboutButton.Click += new System.EventHandler(this.AboutButton_Click);
            // 
            // displayLogCheckBox
            // 
            this.displayLogCheckBox.AutoSize = true;
            this.displayLogCheckBox.Checked = true;
            this.displayLogCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.displayLogCheckBox.Location = new System.Drawing.Point(19, 75);
            this.displayLogCheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.displayLogCheckBox.Name = "displayLogCheckBox";
            this.displayLogCheckBox.Size = new System.Drawing.Size(131, 29);
            this.displayLogCheckBox.TabIndex = 28;
            this.displayLogCheckBox.Text = "Display Log";
            this.displayLogCheckBox.UseVisualStyleBackColor = true;
            // 
            // clearButton
            // 
            this.clearButton.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.clearButton.Location = new System.Drawing.Point(632, 79);
            this.clearButton.Margin = new System.Windows.Forms.Padding(2);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(56, 26);
            this.clearButton.TabIndex = 30;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(17, 16);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(44, 25);
            this.label39.TabIndex = 31;
            this.label39.Text = "Port";
            // 
            // connectionSpeedLabel
            // 
            this.connectionSpeedLabel.Font = new System.Drawing.Font("Segoe UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.connectionSpeedLabel.Location = new System.Drawing.Point(521, 21);
            this.connectionSpeedLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.connectionSpeedLabel.Name = "connectionSpeedLabel";
            this.connectionSpeedLabel.Size = new System.Drawing.Size(198, 31);
            this.connectionSpeedLabel.TabIndex = 32;
            // 
            // ReadRAMButton
            // 
            this.ReadRAMButton.Location = new System.Drawing.Point(728, 124);
            this.ReadRAMButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ReadRAMButton.Name = "ReadRAMButton";
            this.ReadRAMButton.Size = new System.Drawing.Size(231, 39);
            this.ReadRAMButton.TabIndex = 33;
            this.ReadRAMButton.Text = "&Read Current RAM";
            this.ReadRAMButton.UseVisualStyleBackColor = true;
            this.ReadRAMButton.Click += new System.EventHandler(this.ReadRAMButton_Click);
            // 
            // MainForm
            // 
            this.AcceptButton = this.SendButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1422, 1020);
            this.Controls.Add(this.ReadRAMButton);
            this.Controls.Add(this.connectionSpeedLabel);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.displayLogCheckBox);
            this.Controls.Add(this.AboutButton);
            this.Controls.Add(this.connectionStatusPictureBox);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.OutputRichtext);
            this.Controls.Add(this.SendButton);
            this.Controls.Add(this.CommandTextbox);
            this.Controls.Add(this.PortsCombo);
            this.Controls.Add(this.ConnectButton);
            this.Margin = new System.Windows.Forms.Padding(1);
            this.Name = "MainForm";
            this.Text = "8-bit Computer Interface";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.connectionStatusPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ConnectButton;
        private System.Windows.Forms.ComboBox PortsCombo;
        private System.Windows.Forms.TextBox CommandTextbox;
        private System.Windows.Forms.Button SendButton;
        private System.Windows.Forms.RichTextBox OutputRichtext;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button ProgramRAMButton;
        private System.Windows.Forms.TextBox Mem1001;
        private System.Windows.Forms.TextBox Mem1010;
        private System.Windows.Forms.TextBox Mem1011;
        private System.Windows.Forms.TextBox Mem1100;
        private System.Windows.Forms.TextBox Mem1101;
        private System.Windows.Forms.TextBox Mem1110;
        private System.Windows.Forms.TextBox Mem1111;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox Mem1000;
        private System.Windows.Forms.TextBox Mem0001;
        private System.Windows.Forms.TextBox Mem0010;
        private System.Windows.Forms.TextBox Mem0011;
        private System.Windows.Forms.TextBox Mem0100;
        private System.Windows.Forms.TextBox Mem0101;
        private System.Windows.Forms.TextBox Mem0110;
        private System.Windows.Forms.TextBox Mem0111;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox Mem0000;
        private System.Windows.Forms.Label code1001;
        private System.Windows.Forms.Label code1010;
        private System.Windows.Forms.Label code1011;
        private System.Windows.Forms.Label code1100;
        private System.Windows.Forms.Label code1101;
        private System.Windows.Forms.Label code1110;
        private System.Windows.Forms.Label code1111;
        private System.Windows.Forms.Label code1000;
        private System.Windows.Forms.Label code0001;
        private System.Windows.Forms.Label code0010;
        private System.Windows.Forms.Label code0011;
        private System.Windows.Forms.Label code0100;
        private System.Windows.Forms.Label code0101;
        private System.Windows.Forms.Label code0110;
        private System.Windows.Forms.Label code0111;
        private System.Windows.Forms.Label code0000;
        private System.Windows.Forms.PictureBox connectionStatusPictureBox;
        private System.Windows.Forms.Button AboutButton;
        private System.Windows.Forms.ComboBox loadSetCombo;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.CheckBox displayLogCheckBox;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label connectionSpeedLabel;
        private System.Windows.Forms.Button ReadRAMButton;
    }
}

