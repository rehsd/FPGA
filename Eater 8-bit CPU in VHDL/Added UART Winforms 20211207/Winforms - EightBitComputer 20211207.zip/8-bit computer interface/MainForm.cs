﻿/*
    This application is used in conjunction with an Arduino Mega to set RAM values, 
    read the bus, control bits, output, and clock speed of an 8-bit computer 
    based on Ben Eater's 8-bit computer reference design.   
    See https://github.com/rehsd/8-bit-computer-interface--Arduino.

    Last updated July 21, 2021.

    The higher the 8-bit computer clock, the more monitoring will struggle to keep up read all of the data.
    At 115200 baud, a clock of ~100Hz is the ceiling. 
    At 921600 baud, monitoring does pretty well keeping up. However, writing to the Arduino/8-bit computer will struggle.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Configuration;
using System.Management;

namespace EightBitInterface
{
    public partial class MainForm : Form
    {
        SerialPort myPort;
        bool bHex = true;


        const short MAX_OUTPUT_LINES = 300;
        const int CONNECTION_RATE = 460800; //Match with speed setting on uartlite in Vivado block design
                                            
        public MainForm()
        {
            InitializeComponent();
        }

        void PopulateSerialPorts()
        {
            try
            {
                //ManagementObjectCollection mbsList = null;
                //ManagementObjectSearcher mbs = new ManagementObjectSearcher("Select DeviceID, Description From Win32_SerialPort");
                //mbsList = mbs.Get();

                //foreach (ManagementObject mo in mbsList)
                //{
                //    PortsCombo.Items.Add(mo["DeviceID"].ToString() + ": " + mo["Description"].ToString());
                //}

                string[] ports = SerialPort.GetPortNames();
                foreach (string port in ports)
                {
                    PortsCombo.Items.Add(port + ":");
                }

            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateSerialPorts();

                foreach (string profileSet in ConfigurationManager.AppSettings)
                {
                    loadSetCombo.Items.Add(profileSet);
                }

                //Default programming values
                Mem0000.Text = "00011111";  //load from 15
                Mem0001.Text = "11100000";  //out
                Mem0010.Text = "00101110";  //add from 14
                Mem0011.Text = "11100000";  //out
                Mem0100.Text = "00101110";  //subtract from 13
                Mem0101.Text = "11100000";  //out
                Mem0110.Text = "00101110";  //add from 14
                Mem0111.Text = "11100000";  //out
                Mem1000.Text = "00101110";  //subtract from 13
                Mem1001.Text = "11100000";  //out
                Mem1010.Text = "00101110";  //subtract from 13
                Mem1011.Text = "11100000";  //out
                Mem1100.Text = "01100010";  //out
                Mem1101.Text = "00000000";  //7
                Mem1110.Text = "00000010";  //6
                Mem1111.Text = "00000001";  //5

                SetFormControls(false);

                Advise();


                Mem0000.Enter += new EventHandler(Txt_Enter);
                Mem0000.MouseClick += new MouseEventHandler(Txt_Enter);
                Mem0001.Enter += new EventHandler(Txt_Enter);
                Mem0001.MouseClick += new MouseEventHandler(Txt_Enter);
                Mem0010.Enter += new EventHandler(Txt_Enter);
                Mem0010.MouseClick += new MouseEventHandler(Txt_Enter);
                Mem0011.Enter += new EventHandler(Txt_Enter);
                Mem0011.MouseClick += new MouseEventHandler(Txt_Enter);
                Mem0101.Enter += new EventHandler(Txt_Enter);
                Mem0101.MouseClick += new MouseEventHandler(Txt_Enter);
                Mem0110.Enter += new EventHandler(Txt_Enter);
                Mem0110.MouseClick += new MouseEventHandler(Txt_Enter);
                Mem0111.Enter += new EventHandler(Txt_Enter);
                Mem0111.MouseClick += new MouseEventHandler(Txt_Enter);
                Mem1000.Enter += new EventHandler(Txt_Enter);
                Mem1000.MouseClick += new MouseEventHandler(Txt_Enter);
                Mem1001.Enter += new EventHandler(Txt_Enter);
                Mem1001.MouseClick += new MouseEventHandler(Txt_Enter);
                Mem1010.Enter += new EventHandler(Txt_Enter);
                Mem1010.MouseClick += new MouseEventHandler(Txt_Enter);
                Mem1011.Enter += new EventHandler(Txt_Enter);
                Mem1011.MouseClick += new MouseEventHandler(Txt_Enter);
                Mem1100.Enter += new EventHandler(Txt_Enter);
                Mem1100.MouseClick += new MouseEventHandler(Txt_Enter);
                Mem1101.Enter += new EventHandler(Txt_Enter);
                Mem1101.MouseClick += new MouseEventHandler(Txt_Enter);
                Mem1110.Enter += new EventHandler(Txt_Enter);
                Mem1110.MouseClick += new MouseEventHandler(Txt_Enter);
                Mem1111.Enter += new EventHandler(Txt_Enter);
                Mem1111.MouseClick += new MouseEventHandler(Txt_Enter);

            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void Txt_Enter(object sender, EventArgs e)
        {
            TextBox txt = sender as TextBox;
            txt.Select();
            txt.Select(0, txt.Text.Length);
        }
        private void ConnectButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (ConnectButton.Text == "&Connect")
                {
                    string s = PortsCombo.SelectedItem.ToString();
                    s = s.Substring(0, s.IndexOf(":"));
                    myPort = new SerialPort(s, CONNECTION_RATE); 
                    myPort.ReadTimeout = 5000;
                    myPort.WriteTimeout = 5000;
                    myPort.Open();
                    connectionStatusPictureBox.BackColor = Color.Green;
                    System.Threading.Thread.Sleep(1000);
                    myPort.DataReceived += new SerialDataReceivedEventHandler(MyPort_DataReceived);
                    myPort.DiscardInBuffer();
                    OutputRichtext.Text += "\nConnected at " + myPort.BaudRate.ToString() + "!\n";
                    connectionSpeedLabel.Text = s + " @ " + myPort.BaudRate.ToString();
                    ConnectButton.Text = "&Disconnect";
                    SetFormControls(true);
                }
                else
                {
                    if (myPort.IsOpen)
                    {
                        myPort.Close();
                    }
                    connectionStatusPictureBox.BackColor = Color.Red;
                    OutputRichtext.Text += "Disconnected!\n";
                    ConnectButton.Text = "&Connect";
                    SetFormControls(false);
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void MyPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                if (InvokeRequired)
                {
                    this.Invoke(new MethodInvoker(delegate
                    {
                        if (OutputRichtext.Lines.Length > MAX_OUTPUT_LINES)
                        {
                            List<string> lines = OutputRichtext.Lines.ToList();
                            lines.RemoveRange(0, lines.Count - MAX_OUTPUT_LINES);
                            OutputRichtext.Lines = lines.ToArray();
                        }

                        string stmp = "";
                        stmp = myPort.ReadExisting();
                        
                        bool bSkipped = false;
                        if (bHex)
                        {
                            //Convert complete hex string to complete binary string
                            stmp = ConvertHexBufferToBinaryBuffer(stmp, ref bSkipped);
                        }


                        OutputRichtext.Text += stmp + "\r";

                    }));
                }
                else
                {
                    //OutputRichtext.Text = myPort.ReadLine();
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        void Advise()
        {
            OutputRichtext.Text += "Welcome!";
        }

        string ConvertHexBufferToBinaryBuffer(string hexBuffer, ref bool skipped)
        {
            //sample in --> BBCCCCFFCCCC
            //sample out -->  Bus: 00000000  Control: 0000010000000010  Out: 00010110[255]  Clock: 9999

            try
            {
                //TO DO Better validation / exception handling
                if (hexBuffer.Contains(">") || hexBuffer.Contains(":") || hexBuffer.Contains(">") || hexBuffer.Contains("[") || hexBuffer.Contains(" '"))
                {
                    skipped = true;
                    return hexBuffer;
                }

                hexBuffer = hexBuffer.Replace("\r", "");

                if (hexBuffer.Length != 12)
                {
                    skipped = true;
                    return hexBuffer;
                }

                skipped = false;
                string sTemp = "";
                string sBus = hexBuffer.Substring(0, 2);
                string sControl = hexBuffer.Substring(2, 4);
                string sOut = hexBuffer.Substring(6, 2);
                string sClock = hexBuffer.Substring(8, 4);

                sBus = Convert.ToString(Convert.ToInt32(sBus, 16), 2);
                sControl = Convert.ToString(Convert.ToInt32(sControl, 16), 2);
                string sOutDec = Convert.ToString(Convert.ToInt32(sOut, 16), 10);
                sOut = Convert.ToString(Convert.ToInt32(sOut, 16), 2);
                sClock = Convert.ToString(Convert.ToInt32(sClock, 16), 10);

                sBus = sBus.PadLeft(8, '0');
                sControl = sControl.PadLeft(16, '0');
                sOut = sOut.PadLeft(8, '0');

                sTemp = "Bus:" + sBus + "  Control:" + sControl + "  Out:" + sOut + " [" + sOutDec + "]" + "  Clock:" + sClock;

                return sTemp;
            }
            catch
            {
                //Do nothing for now...
                return "";
            }
        }





        private void SendButton_Click(object sender, EventArgs e)
        {
            try
            {
                myPort.Write(CommandTextbox.Text + "\n");
                CommandTextbox.Clear();
                CommandTextbox.Focus();
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }

        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (myPort != null && myPort.IsOpen)
                {
                    myPort.Close();
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }

        }

        private static void UpdateOpCodeLabel(TextBox t, Label opCodeLabel)
        {
            try
            {
                switch (t.Text.Substring(0, 4))
                {
                    case "0001":    //LDA
                        {
                            opCodeLabel.Text = "LDA";
                            break;
                        }
                    case "0010":    //ADD
                        {
                            opCodeLabel.Text = "ADD";
                            break;
                        }
                    case "0011":    //  SUB
                        {
                            opCodeLabel.Text = "SUB";
                            break;
                        }
                    case "0100":    //  STA
                        {
                            opCodeLabel.Text = "STA";
                            break;
                        }
                    case "0101":    //LDI
                        {
                            opCodeLabel.Text = "LDI";
                            break;
                        }
                    case "0110":    //JMP
                        {
                            opCodeLabel.Text = "JMP";
                            break;
                        }
                    case "0111":    //JC
                        {
                            opCodeLabel.Text = "JC";
                            break;
                        }
                    case "1000":    //JZ
                        {
                            opCodeLabel.Text = "JZ";
                            break;
                        }
                    case "1110":    //OUT
                        {
                            opCodeLabel.Text = "OUT";
                            break;
                        }
                    case "1111":    //HLT
                        {
                            opCodeLabel.Text = "HLT";
                            break;
                        }
                    default:
                        {
                            opCodeLabel.Text = "NonOp";
                            break;
                        }
                }
            }
            catch (Exception)
            {
                //do nothing for now...
            }
        }

        #region MemXXXX_TextChanged event handlers

        private void Mem0000_TextChanged(object sender, EventArgs e)
        {
            UpdateOpCodeLabel((TextBox)sender, code0000);
        }

        private void Mem0001_TextChanged(object sender, EventArgs e)
        {
            UpdateOpCodeLabel((TextBox)sender, code0001);

        }

        private void Mem0010_TextChanged(object sender, EventArgs e)
        {
            UpdateOpCodeLabel((TextBox)sender, code0010);

        }

        private void Mem011_TextChanged(object sender, EventArgs e)
        {
            UpdateOpCodeLabel((TextBox)sender, code0011);
        }

        private void Mem0100_TextChanged(object sender, EventArgs e)
        {
            UpdateOpCodeLabel((TextBox)sender, code0100);

        }

        private void Mem0101_TextChanged(object sender, EventArgs e)
        {
            UpdateOpCodeLabel((TextBox)sender, code0101);

        }

        private void Mem0110_TextChanged(object sender, EventArgs e)
        {
            UpdateOpCodeLabel((TextBox)sender, code0110);

        }

        private void Mem0111_TextChanged(object sender, EventArgs e)
        {
            UpdateOpCodeLabel((TextBox)sender, code0111);

        }

        private void Mem1000_TextChanged(object sender, EventArgs e)
        {
            UpdateOpCodeLabel((TextBox)sender, code1000);

        }

        private void Mem1001_TextChanged(object sender, EventArgs e)
        {
            UpdateOpCodeLabel((TextBox)sender, code1001);

        }

        private void Mem1010_TextChanged(object sender, EventArgs e)
        {
            UpdateOpCodeLabel((TextBox)sender, code1010);

        }

        private void Mem1011_TextChanged(object sender, EventArgs e)
        {
            UpdateOpCodeLabel((TextBox)sender, code1011);

        }

        private void Mem1100_TextChanged(object sender, EventArgs e)
        {
            UpdateOpCodeLabel((TextBox)sender, code1100);

        }

        private void Mem1101_TextChanged(object sender, EventArgs e)
        {
            UpdateOpCodeLabel((TextBox)sender, code1101);

        }

        private void Mem1110_TextChanged(object sender, EventArgs e)
        {
            UpdateOpCodeLabel((TextBox)sender, code1110);

        }

        private void Mem1111_TextChanged(object sender, EventArgs e)
        {
            UpdateOpCodeLabel((TextBox)sender, code1111);

        }
        #endregion




        private void ProgramRAMButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("About to write to RAM. Would you like to procced?", "RAM update", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    int delay = 50;
                    OutputRichtext.Text += "Programming:\n";
                    System.Threading.Thread.Sleep(delay); //slight delay

                    OutputRichtext.Text += "0000\n";
                    myPort.Write("2" + "\n");      //update RAM menu item
                    System.Threading.Thread.Sleep(delay); //slight delay
                    myPort.Write("0000" + Mem0000.Text + "\n");
                    System.Threading.Thread.Sleep(delay); //slight delay

                    OutputRichtext.Text += "0001\n";
                    myPort.Write("2" + "\n");      //update RAM menu item
                    System.Threading.Thread.Sleep(delay); //slight delay
                    myPort.Write("0001" + Mem0001.Text + "\n");
                    System.Threading.Thread.Sleep(delay); //slight delay

                    OutputRichtext.Text += "0010\n";
                    myPort.Write("2" + "\n");      //update RAM menu item
                    System.Threading.Thread.Sleep(delay); //slight delay
                    myPort.Write("0010" + Mem0010.Text + "\n");
                    System.Threading.Thread.Sleep(delay); //slight delay

                    OutputRichtext.Text += "0011\n";
                    myPort.Write("2" + "\n");      //update RAM menu item
                    System.Threading.Thread.Sleep(delay); //slight delay
                    myPort.Write("0011" + Mem0011.Text + "\n");
                    System.Threading.Thread.Sleep(delay); //slight delay

                    OutputRichtext.Text += "0100\n";
                    myPort.Write("2" + "\n");      //update RAM menu item
                    System.Threading.Thread.Sleep(delay); //slight delay
                    myPort.Write("0100" + Mem0100.Text + "\n");
                    System.Threading.Thread.Sleep(delay); //slight delay

                    OutputRichtext.Text += "0101\n";
                    myPort.Write("2" + "\n");      //update RAM menu item
                    System.Threading.Thread.Sleep(delay); //slight delay
                    myPort.Write("0101" + Mem0101.Text + "\n");
                    System.Threading.Thread.Sleep(delay); //slight delay

                    OutputRichtext.Text += "0110\n";
                    myPort.Write("2" + "\n");      //update RAM menu item
                    System.Threading.Thread.Sleep(delay); //slight delay
                    myPort.Write("0110" + Mem0110.Text + "\n");
                    System.Threading.Thread.Sleep(delay); //slight delay

                    OutputRichtext.Text += "0111\n";
                    myPort.Write("2" + "\n");      //update RAM menu item
                    System.Threading.Thread.Sleep(delay); //slight delay
                    myPort.Write("0111" + Mem0111.Text + "\n");
                    System.Threading.Thread.Sleep(delay); //slight delay

                    OutputRichtext.Text += "1000\n";
                    myPort.Write("2" + "\n");      //update RAM menu item
                    System.Threading.Thread.Sleep(delay); //slight delay
                    myPort.Write("1000" + Mem1000.Text + "\n");
                    System.Threading.Thread.Sleep(delay); //slight delay

                    OutputRichtext.Text += "1001\n";
                    myPort.Write("2" + "\n");      //update RAM menu item
                    System.Threading.Thread.Sleep(delay); //slight delay
                    myPort.Write("1001" + Mem1001.Text + "\n");
                    System.Threading.Thread.Sleep(delay); //slight delay

                    OutputRichtext.Text += "1010\n";
                    myPort.Write("2" + "\n");      //update RAM menu item
                    System.Threading.Thread.Sleep(delay); //slight delay
                    myPort.Write("1010" + Mem1010.Text + "\n");
                    System.Threading.Thread.Sleep(delay); //slight delay

                    OutputRichtext.Text += "1011\n";
                    myPort.Write("2" + "\n");      //update RAM menu item
                    System.Threading.Thread.Sleep(delay); //slight delay
                    myPort.Write("1011" + Mem1011.Text + "\n");
                    System.Threading.Thread.Sleep(delay); //slight delay

                    OutputRichtext.Text += "1100\n";
                    myPort.Write("2" + "\n");      //update RAM menu item
                    System.Threading.Thread.Sleep(delay); //slight delay
                    myPort.Write("1100" + Mem1100.Text + "\n");
                    System.Threading.Thread.Sleep(delay); //slight delay

                    OutputRichtext.Text += "1101\n";
                    myPort.Write("2" + "\n");      //update RAM menu item
                    System.Threading.Thread.Sleep(delay); //slight delay
                    myPort.Write("1101" + Mem1101.Text + "\n");
                    System.Threading.Thread.Sleep(delay); //slight delay

                    OutputRichtext.Text += "1110\n";
                    myPort.Write("2" + "\n");      //update RAM menu item
                    System.Threading.Thread.Sleep(delay); //slight delay
                    myPort.Write("1110" + Mem1110.Text + "\n");
                    System.Threading.Thread.Sleep(delay); //slight delay

                    OutputRichtext.Text += "1111\n";
                    myPort.Write("2" + "\n");      //update RAM menu item
                    System.Threading.Thread.Sleep(delay); //slight delay
                    myPort.Write("1111" + Mem1111.Text + "\n");
                    System.Threading.Thread.Sleep(delay); //slight delay

                    OutputRichtext.Text += "Resetting registers\n";
                    myPort.Write("3" + "\n");      //Reset menu item
                    System.Threading.Thread.Sleep(delay); //slight delay

                    if (MessageBox.Show("Return Run/Program switch to the Run mode. Ready to continue?", "RAM update", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        System.Threading.Thread.Sleep(500); //slight delay
                        myPort.Write("4" + "\n");      //continue menu item
                        System.Threading.Thread.Sleep(500); //slight delay
                        OutputRichtext.Text += "Success!\n";
                    }
                }



            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }

        }

        #region codeXXXX_Click event handlers:

        //TODO Consolidate the following Click event handlers...
        private void code0000_Click(object sender, EventArgs e)
        {
            if (code0000.Text=="NonOp")
            {
                UpdateOpCodeLabel(Mem0000, code0000);
            }
            else
            {
                code0000.Text = "NonOp";
            }
        }

        private void code0001_Click(object sender, EventArgs e)
        {
            if (code0001.Text == "NonOp")
            {
                UpdateOpCodeLabel(Mem0001, code0001);
            }
            else
            {
                code0001.Text = "NonOp";
            }
        }

        private void code0010_Click(object sender, EventArgs e)
        {
            if (code0010.Text == "NonOp")
            {
                UpdateOpCodeLabel(Mem0010, code0010);
            }
            else
            {
                code0010.Text = "NonOp";
            }
        }

        private void code0011_Click(object sender, EventArgs e)
        {
            if (code0011.Text == "NonOp")
            {
                UpdateOpCodeLabel(Mem0011, code0011);
            }
            else
            {
                code0011.Text = "NonOp";
            }
        }

        private void code0100_Click(object sender, EventArgs e)
        {
            if (code0100.Text == "NonOp")
            {
                UpdateOpCodeLabel(Mem0100, code0100);
            }
            else
            {
                code0100.Text = "NonOp";
            }
        }

        private void code0101_Click(object sender, EventArgs e)
        {
            if (code0101.Text == "NonOp")
            {
                UpdateOpCodeLabel(Mem0101, code0101);
            }
            else
            {
                code0101.Text = "NonOp";
            }
        }

        private void code0110_Click(object sender, EventArgs e)
        {
            if (code0110.Text == "NonOp")
            {
                UpdateOpCodeLabel(Mem0110, code0110);
            }
            else
            {
                code0110.Text = "NonOp";
            }
        }

        private void code0111_Click(object sender, EventArgs e)
        {
            if (code0111.Text == "NonOp")
            {
                UpdateOpCodeLabel(Mem0111, code0111);
            }
            else
            {
                code0111.Text = "NonOp";
            }
        }

        private void code1000_Click(object sender, EventArgs e)
        {
            if (code1000.Text == "NonOp")
            {
                UpdateOpCodeLabel(Mem1000, code1000);
            }
            else
            {
                code1000.Text = "NonOp";
            }
        }

        private void code1001_Click(object sender, EventArgs e)
        {
            if (code1001.Text == "NonOp")
            {
                UpdateOpCodeLabel(Mem1001, code1001);
            }
            else
            {
                code1001.Text = "NonOp";
            }
        }

        private void code1010_Click(object sender, EventArgs e)
        {
            if (code1010.Text == "NonOp")
            {
                UpdateOpCodeLabel(Mem1010, code1010);
            }
            else
            {
                code1010.Text = "NonOp";
            }
        }

        private void code1011_Click(object sender, EventArgs e)
        {
            if (code1011.Text == "NonOp")
            {
                UpdateOpCodeLabel(Mem1011, code1011);
            }
            else
            {
                code1011.Text = "NonOp";
            }
        }


        private void code1100_Click(object sender, EventArgs e)
        {
            if (code1100.Text == "NonOp")
            {
                UpdateOpCodeLabel(Mem1100, code1100);
            }
            else
            {
                code1100.Text = "NonOp";
            }
        }

        private void code1101_Click(object sender, EventArgs e)
        {
            if (code1101.Text == "NonOp")
            {
                UpdateOpCodeLabel(Mem1101, code1101);
            }
            else
            {
                code1101.Text = "NonOp";
            }
        }

        private void code1110_Click(object sender, EventArgs e)
        {
            if (code1110.Text == "NonOp")
            {
                UpdateOpCodeLabel(Mem1110, code1110);
            }
            else
            {
                code1110.Text = "NonOp";
            }
        }

        private void code1111_Click(object sender, EventArgs e)
        {
            if (code1111.Text == "NonOp")
            {
                UpdateOpCodeLabel(Mem1111, code1111);
            }
            else
            {
                code1111.Text = "NonOp";
            }
        }

        #endregion

        private void MemXXXX_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Bound to all the MemXXXX textboxes to filter kepresses down to 1, 0, and Backspace
            if(e.KeyChar!='1' && e.KeyChar!='0' && e.KeyChar != ((char)Keys.Back))
            {
                e.Handled = true;
            }
        }

        private void MemXXXX_Leave(object sender, EventArgs e)
        {
            //Bound to all the MemXXXX textboxes to pad contents to 8 bits, if fewer than 8 bits were entered
            TextBox t = (TextBox)(sender);
            if(t.TextLength<8)
            {
                t.Text = t.Text.PadRight(8, '0');
            }
        }

        void SetFormControls(bool enableControls)
        {
            CommandTextbox.Enabled = enableControls;
            SendButton.Enabled = enableControls;
            ProgramRAMButton.Enabled = enableControls;
            ReadRAMButton.Enabled = enableControls;
        }

        private void AboutButton_Click(object sender, EventArgs e)
        {
            AboutBox a = new AboutBox();
            a.Show();
        }

        private void loadSetCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string vals = ConfigurationManager.AppSettings[loadSetCombo.Text];
                string[] valArray = vals.Split(":");
                Mem0000.Text = valArray[0];
                Mem0001.Text = valArray[1];
                Mem0010.Text = valArray[2];
                Mem0011.Text = valArray[3];
                Mem0100.Text = valArray[4];
                Mem0101.Text = valArray[5];
                Mem0110.Text = valArray[6];
                Mem0111.Text = valArray[7];
                Mem1000.Text = valArray[8];
                Mem1001.Text = valArray[9];
                Mem1010.Text = valArray[10];
                Mem1011.Text = valArray[11];
                Mem1100.Text = valArray[12];
                Mem1101.Text = valArray[13];
                Mem1110.Text = valArray[14];
                Mem1111.Text = valArray[15];
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void PortsCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            ConnectButton.Enabled = true;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            OutputRichtext.Clear();
        }

        private void OutputRichtext_TextChanged(object sender, EventArgs e)
        {
            OutputRichtext.SelectionStart = OutputRichtext.Text.Length;
            OutputRichtext.ScrollToCaret();
        }

        private void ReadRAMButton_Click(object sender, EventArgs e)
        {
            myPort.Write("1" + "\n");      //read RAM menu item
            System.Threading.Thread.Sleep(100); //slight delay
        }
    }
}
