#include <stdio.h>
#include "platform.h"
#include "xv_tpg.h"
#include "xvidc.h"
#include "xil_printf.h"

#include "xil_assert.h"

u8 tpg_alpha = 0x00;
//void print(char *str);

int main()
{
	xil_printf("start main");
    XV_tpg ptpg;
    XV_tpg_Config *ptpg_config;

    init_platform();

    ptpg_config = XV_tpg_LookupConfig(XPAR_V_TPG_0_DEVICE_ID);
    XV_tpg_CfgInitialize(&ptpg, ptpg_config, ptpg_config->BaseAddress);


    xil_printf("TPG Initialization\r\n");


    u32 height,width,status;

    status = XV_tpg_IsReady(&ptpg);
    xil_printf("Status %u \n\r", (unsigned int) status);
    status = XV_tpg_IsIdle(&ptpg);
    xil_printf("Status %u \n\r", (unsigned int) status);
    XV_tpg_Set_height(&ptpg, (u32)480);
    XV_tpg_Set_width(&ptpg, (u32)640);
    height = XV_tpg_Get_height(&ptpg);
    width = XV_tpg_Get_width(&ptpg);
    XV_tpg_Set_colorFormat(&ptpg,XVIDC_CSF_RGB);
    XV_tpg_Set_maskId(&ptpg, 0x0);
    XV_tpg_Set_motionSpeed(&ptpg, 0x4);
    xil_printf("info from tpg %u %u \n\r", (unsigned int)height, (unsigned int)width);

    while(1)
    {
		XV_tpg_Set_bckgndId(&ptpg, XTPG_BKGND_CHECKER_BOARD);
		status = XV_tpg_Get_bckgndId(&ptpg);
		xil_printf("Status %x \n\r", (unsigned int) status);
		XV_tpg_EnableAutoRestart(&ptpg);
		XV_tpg_Start(&ptpg);
		status = XV_tpg_IsIdle(&ptpg);
		xil_printf("Status %u \n\r", (unsigned int) status);


		for(u32 i = 0; i<10000000; i++)
		{
			//nothing
		}

		XV_tpg_Set_bckgndId(&ptpg, XTPG_BKGND_CROSS_HATCH);
		status = XV_tpg_Get_bckgndId(&ptpg);
		xil_printf("Status %x \n\r", (unsigned int) status);
		XV_tpg_EnableAutoRestart(&ptpg);
		XV_tpg_Start(&ptpg);
		status = XV_tpg_IsIdle(&ptpg);
		xil_printf("Status %u \n\r", (unsigned int) status);

		for(u32 i = 0; i<10000000; i++)
		{
			//nothing
		}

		XV_tpg_Set_bckgndId(&ptpg, XTPG_BKGND_COLOR_BARS);
		status = XV_tpg_Get_bckgndId(&ptpg);
		xil_printf("Status %x \n\r", (unsigned int) status);
		XV_tpg_EnableAutoRestart(&ptpg);
		XV_tpg_Start(&ptpg);
		status = XV_tpg_IsIdle(&ptpg);
		xil_printf("Status %u \n\r", (unsigned int) status);

		for(u32 i = 0; i<10000000; i++)
		{
			//nothing
		}

		XV_tpg_Set_bckgndId(&ptpg, XTPG_BKGND_PBRS);
		status = XV_tpg_Get_bckgndId(&ptpg);
		xil_printf("Status %x \n\r", (unsigned int) status);
		XV_tpg_EnableAutoRestart(&ptpg);
		XV_tpg_Start(&ptpg);
		status = XV_tpg_IsIdle(&ptpg);
		xil_printf("Status %u \n\r", (unsigned int) status);

		for(u32 i = 0; i<10000000; i++)
		{
			//nothing
		}

		XV_tpg_Set_bckgndId(&ptpg, XTPG_BKGND_TARTAN_COLOR_BARS);
		status = XV_tpg_Get_bckgndId(&ptpg);
		xil_printf("Status %x \n\r", (unsigned int) status);
		XV_tpg_EnableAutoRestart(&ptpg);
		XV_tpg_Start(&ptpg);
		status = XV_tpg_IsIdle(&ptpg);
		xil_printf("Status %u \n\r", (unsigned int) status);
    }

    return 0;
}
